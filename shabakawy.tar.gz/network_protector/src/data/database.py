#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Database Module
وحدة قاعدة البيانات لحفظ السجلات والإحصائيات
"""

import sqlite3
import json
import time
from datetime import datetime, timedelta
import threading
from PyQt5.QtCore import QObject, pyqtSignal

class DatabaseManager(QObject):
    """مدير قاعدة البيانات"""
    
    # إشارات PyQt
    data_updated = pyqtSignal(str)  # نوع البيانات المحدثة
    
    def __init__(self, db_path="network_protector.db"):
        super().__init__()
        self.db_path = db_path
        self.connection = None
        self.lock = threading.Lock()
        
        # إنشاء قاعدة البيانات والجداول
        self.init_database()
    
    def init_database(self):
        """إنشاء قاعدة البيانات والجداول"""
        try:
            self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
            self.connection.row_factory = sqlite3.Row  # للوصول للأعمدة بالاسم
            
            cursor = self.connection.cursor()
            
            # جدول الحزم المُلتقطة
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS packets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    src_ip TEXT,
                    dst_ip TEXT,
                    src_port INTEGER,
                    dst_port INTEGER,
                    protocol TEXT,
                    size INTEGER,
                    summary TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # جدول التهديدات المكتشفة
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    threat_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    source_ip TEXT,
                    target_ip TEXT,
                    description TEXT,
                    action_taken TEXT,
                    additional_data TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # جدول الأجهزة المكتشفة
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS devices (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip_address TEXT UNIQUE NOT NULL,
                    mac_address TEXT,
                    hostname TEXT,
                    vendor TEXT,
                    device_type TEXT,
                    first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_online BOOLEAN DEFAULT 1,
                    open_ports TEXT,
                    additional_info TEXT
                )
            ''')
            
            # جدول إحصائيات الشبكة
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS network_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    packets_count INTEGER DEFAULT 0,
                    bytes_received INTEGER DEFAULT 0,
                    bytes_sent INTEGER DEFAULT 0,
                    tcp_packets INTEGER DEFAULT 0,
                    udp_packets INTEGER DEFAULT 0,
                    icmp_packets INTEGER DEFAULT 0,
                    other_packets INTEGER DEFAULT 0,
                    active_connections INTEGER DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # جدول سجل الأحداث
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS event_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    event_type TEXT NOT NULL,
                    level TEXT NOT NULL,
                    message TEXT NOT NULL,
                    source TEXT,
                    additional_data TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # جدول إعدادات التطبيق
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # إنشاء فهارس لتحسين الأداء
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_packets_timestamp ON packets(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_threats_timestamp ON threats(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_threats_type ON threats(threat_type)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_devices_ip ON devices(ip_address)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_network_stats_timestamp ON network_stats(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_event_logs_timestamp ON event_logs(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_event_logs_type ON event_logs(event_type)')
            
            self.connection.commit()
            
        except Exception as e:
            print(f"خطأ في إنشاء قاعدة البيانات: {e}")
    
    def save_packet(self, packet_info):
        """حفظ معلومات حزمة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cursor.execute('''
                    INSERT INTO packets (timestamp, src_ip, dst_ip, src_port, dst_port, 
                                       protocol, size, summary)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    packet_info.get('timestamp', time.time()),
                    packet_info.get('src_ip', ''),
                    packet_info.get('dst_ip', ''),
                    packet_info.get('src_port'),
                    packet_info.get('dst_port'),
                    packet_info.get('protocol', ''),
                    packet_info.get('size', 0),
                    packet_info.get('summary', '')
                ))
                self.connection.commit()
                self.data_updated.emit('packets')
                
        except Exception as e:
            print(f"خطأ في حفظ الحزمة: {e}")
    
    def save_threat(self, threat_info):
        """حفظ معلومات تهديد"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cursor.execute('''
                    INSERT INTO threats (timestamp, threat_type, severity, source_ip, 
                                       target_ip, description, action_taken, additional_data)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    threat_info.get('timestamp', time.time()),
                    threat_info.get('type', ''),
                    threat_info.get('severity', ''),
                    threat_info.get('source_ip', ''),
                    threat_info.get('target_ip', ''),
                    threat_info.get('description', ''),
                    threat_info.get('action_taken', ''),
                    json.dumps(threat_info.get('additional_data', {}))
                ))
                self.connection.commit()
                self.data_updated.emit('threats')
                
        except Exception as e:
            print(f"خطأ في حفظ التهديد: {e}")
    
    def save_device(self, device_info):
        """حفظ أو تحديث معلومات جهاز"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                
                # التحقق من وجود الجهاز
                cursor.execute('SELECT id FROM devices WHERE ip_address = ?', 
                             (device_info.get('ip', ''),))
                existing = cursor.fetchone()
                
                if existing:
                    # تحديث الجهاز الموجود
                    cursor.execute('''
                        UPDATE devices SET 
                            mac_address = ?, hostname = ?, vendor = ?, device_type = ?,
                            last_seen = CURRENT_TIMESTAMP, is_online = ?, open_ports = ?,
                            additional_info = ?
                        WHERE ip_address = ?
                    ''', (
                        device_info.get('mac_address', ''),
                        device_info.get('hostname', ''),
                        device_info.get('vendor', ''),
                        device_info.get('device_type', ''),
                        device_info.get('status', '') == 'Online',
                        json.dumps(device_info.get('open_ports', [])),
                        json.dumps(device_info.get('additional_info', {})),
                        device_info.get('ip', '')
                    ))
                else:
                    # إضافة جهاز جديد
                    cursor.execute('''
                        INSERT INTO devices (ip_address, mac_address, hostname, vendor, 
                                           device_type, is_online, open_ports, additional_info)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        device_info.get('ip', ''),
                        device_info.get('mac_address', ''),
                        device_info.get('hostname', ''),
                        device_info.get('vendor', ''),
                        device_info.get('device_type', ''),
                        device_info.get('status', '') == 'Online',
                        json.dumps(device_info.get('open_ports', [])),
                        json.dumps(device_info.get('additional_info', {}))
                    ))
                
                self.connection.commit()
                self.data_updated.emit('devices')
                
        except Exception as e:
            print(f"خطأ في حفظ الجهاز: {e}")
    
    def save_network_stats(self, stats):
        """حفظ إحصائيات الشبكة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cursor.execute('''
                    INSERT INTO network_stats (timestamp, packets_count, bytes_received, 
                                             bytes_sent, tcp_packets, udp_packets, 
                                             icmp_packets, other_packets, active_connections)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    time.time(),
                    stats.get('packet_count', 0),
                    stats.get('bytes_received', 0),
                    stats.get('bytes_sent', 0),
                    stats.get('tcp_packets', 0),
                    stats.get('udp_packets', 0),
                    stats.get('icmp_packets', 0),
                    stats.get('other_packets', 0),
                    stats.get('active_connections', 0)
                ))
                self.connection.commit()
                self.data_updated.emit('network_stats')
                
        except Exception as e:
            print(f"خطأ في حفظ إحصائيات الشبكة: {e}")
    
    def log_event(self, event_type, level, message, source=None, additional_data=None):
        """تسجيل حدث في السجل"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cursor.execute('''
                    INSERT INTO event_logs (timestamp, event_type, level, message, 
                                          source, additional_data)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    time.time(),
                    event_type,
                    level,
                    message,
                    source,
                    json.dumps(additional_data) if additional_data else None
                ))
                self.connection.commit()
                self.data_updated.emit('event_logs')
                
        except Exception as e:
            print(f"خطأ في تسجيل الحدث: {e}")
    
    def get_packets(self, limit=1000, start_time=None, end_time=None):
        """الحصول على الحزم المحفوظة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                
                query = 'SELECT * FROM packets'
                params = []
                
                if start_time or end_time:
                    query += ' WHERE'
                    if start_time:
                        query += ' timestamp >= ?'
                        params.append(start_time)
                    if end_time:
                        if start_time:
                            query += ' AND'
                        query += ' timestamp <= ?'
                        params.append(end_time)
                
                query += ' ORDER BY timestamp DESC LIMIT ?'
                params.append(limit)
                
                cursor.execute(query, params)
                return [dict(row) for row in cursor.fetchall()]
                
        except Exception as e:
            print(f"خطأ في الحصول على الحزم: {e}")
            return []
    
    def get_threats(self, limit=1000, threat_type=None, start_time=None, end_time=None):
        """الحصول على التهديدات المحفوظة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                
                query = 'SELECT * FROM threats'
                params = []
                conditions = []
                
                if threat_type:
                    conditions.append('threat_type = ?')
                    params.append(threat_type)
                
                if start_time:
                    conditions.append('timestamp >= ?')
                    params.append(start_time)
                
                if end_time:
                    conditions.append('timestamp <= ?')
                    params.append(end_time)
                
                if conditions:
                    query += ' WHERE ' + ' AND '.join(conditions)
                
                query += ' ORDER BY timestamp DESC LIMIT ?'
                params.append(limit)
                
                cursor.execute(query, params)
                results = []
                for row in cursor.fetchall():
                    threat = dict(row)
                    if threat['additional_data']:
                        try:
                            threat['additional_data'] = json.loads(threat['additional_data'])
                        except:
                            pass
                    results.append(threat)
                
                return results
                
        except Exception as e:
            print(f"خطأ في الحصول على التهديدات: {e}")
            return []
    
    def get_devices(self, online_only=False):
        """الحصول على الأجهزة المحفوظة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                
                query = 'SELECT * FROM devices'
                if online_only:
                    query += ' WHERE is_online = 1'
                query += ' ORDER BY last_seen DESC'
                
                cursor.execute(query)
                results = []
                for row in cursor.fetchall():
                    device = dict(row)
                    if device['open_ports']:
                        try:
                            device['open_ports'] = json.loads(device['open_ports'])
                        except:
                            device['open_ports'] = []
                    if device['additional_info']:
                        try:
                            device['additional_info'] = json.loads(device['additional_info'])
                        except:
                            device['additional_info'] = {}
                    results.append(device)
                
                return results
                
        except Exception as e:
            print(f"خطأ في الحصول على الأجهزة: {e}")
            return []
    
    def get_network_stats(self, hours=24):
        """الحصول على إحصائيات الشبكة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                
                start_time = time.time() - (hours * 3600)
                cursor.execute('''
                    SELECT * FROM network_stats 
                    WHERE timestamp >= ? 
                    ORDER BY timestamp ASC
                ''', (start_time,))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except Exception as e:
            print(f"خطأ في الحصول على إحصائيات الشبكة: {e}")
            return []
    
    def get_event_logs(self, limit=1000, level=None, event_type=None, start_time=None, end_time=None):
        """الحصول على سجل الأحداث"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                
                query = 'SELECT * FROM event_logs'
                params = []
                conditions = []
                
                if level:
                    conditions.append('level = ?')
                    params.append(level)
                
                if event_type:
                    conditions.append('event_type = ?')
                    params.append(event_type)
                
                if start_time:
                    conditions.append('timestamp >= ?')
                    params.append(start_time)
                
                if end_time:
                    conditions.append('timestamp <= ?')
                    params.append(end_time)
                
                if conditions:
                    query += ' WHERE ' + ' AND '.join(conditions)
                
                query += ' ORDER BY timestamp DESC LIMIT ?'
                params.append(limit)
                
                cursor.execute(query, params)
                results = []
                for row in cursor.fetchall():
                    log = dict(row)
                    if log['additional_data']:
                        try:
                            log['additional_data'] = json.loads(log['additional_data'])
                        except:
                            pass
                    results.append(log)
                
                return results
                
        except Exception as e:
            print(f"خطأ في الحصول على سجل الأحداث: {e}")
            return []
    
    def get_statistics_summary(self, hours=24):
        """الحصول على ملخص الإحصائيات"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                start_time = time.time() - (hours * 3600)
                
                # إحصائيات الحزم
                cursor.execute('''
                    SELECT COUNT(*) as total_packets,
                           SUM(size) as total_bytes,
                           COUNT(DISTINCT src_ip) as unique_sources,
                           COUNT(DISTINCT dst_ip) as unique_destinations
                    FROM packets WHERE timestamp >= ?
                ''', (start_time,))
                packet_stats = dict(cursor.fetchone())
                
                # إحصائيات التهديدات
                cursor.execute('''
                    SELECT threat_type, COUNT(*) as count
                    FROM threats WHERE timestamp >= ?
                    GROUP BY threat_type
                ''', (start_time,))
                threat_stats = {row['threat_type']: row['count'] for row in cursor.fetchall()}
                
                # إحصائيات الأجهزة
                cursor.execute('SELECT COUNT(*) as total_devices FROM devices')
                device_count = cursor.fetchone()['total_devices']
                
                cursor.execute('SELECT COUNT(*) as online_devices FROM devices WHERE is_online = 1')
                online_devices = cursor.fetchone()['online_devices']
                
                return {
                    'packet_stats': packet_stats,
                    'threat_stats': threat_stats,
                    'device_stats': {
                        'total_devices': device_count,
                        'online_devices': online_devices,
                        'offline_devices': device_count - online_devices
                    },
                    'time_range_hours': hours
                }
                
        except Exception as e:
            print(f"خطأ في الحصول على ملخص الإحصائيات: {e}")
            return {}
    
    def cleanup_old_data(self, days_to_keep=30):
        """تنظيف البيانات القديمة"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cutoff_time = time.time() - (days_to_keep * 24 * 3600)
                
                # حذف الحزم القديمة
                cursor.execute('DELETE FROM packets WHERE timestamp < ?', (cutoff_time,))
                packets_deleted = cursor.rowcount
                
                # حذف إحصائيات الشبكة القديمة
                cursor.execute('DELETE FROM network_stats WHERE timestamp < ?', (cutoff_time,))
                stats_deleted = cursor.rowcount
                
                # حذف سجل الأحداث القديم
                cursor.execute('DELETE FROM event_logs WHERE timestamp < ?', (cutoff_time,))
                logs_deleted = cursor.rowcount
                
                self.connection.commit()
                
                self.log_event('cleanup', 'info', 
                             f'تم حذف {packets_deleted} حزمة، {stats_deleted} إحصائية، {logs_deleted} سجل')
                
                return {
                    'packets_deleted': packets_deleted,
                    'stats_deleted': stats_deleted,
                    'logs_deleted': logs_deleted
                }
                
        except Exception as e:
            print(f"خطأ في تنظيف البيانات: {e}")
            return {}
    
    def get_setting(self, key, default=None):
        """الحصول على إعداد"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cursor.execute('SELECT value FROM settings WHERE key = ?', (key,))
                result = cursor.fetchone()
                return result['value'] if result else default
                
        except Exception as e:
            print(f"خطأ في الحصول على الإعداد {key}: {e}")
            return default
    
    def set_setting(self, key, value):
        """تعيين إعداد"""
        try:
            with self.lock:
                cursor = self.connection.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (key, str(value)))
                self.connection.commit()
                
        except Exception as e:
            print(f"خطأ في تعيين الإعداد {key}: {e}")
    
    def close(self):
        """إغلاق قاعدة البيانات"""
        if self.connection:
            self.connection.close()

