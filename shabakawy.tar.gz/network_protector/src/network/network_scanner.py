#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Network Scanner Module
وحدة مسح الشبكة واكتشاف الأجهزة المتصلة
"""

import threading
import time
import socket
import subprocess
import re
from PyQt5.QtCore import QObject, pyqtSignal
import psutil
import ipaddress

class NetworkScanner(QObject):
    """فئة مسح الشبكة واكتشاف الأجهزة"""
    
    # إشارات PyQt
    device_discovered = pyqtSignal(dict)  # إشارة اكتشاف جهاز جديد
    scan_completed = pyqtSignal(list)  # إشارة اكتمال المسح
    scan_progress = pyqtSignal(int)  # إشارة تقدم المسح
    
    def __init__(self):
        super().__init__()
        self.is_scanning = False
        self.scan_thread = None
        self.discovered_devices = []
        
        # معلومات الشبكة المحلية
        self.local_network = None
        self.gateway_ip = None
        self.local_ip = None
        
        # قاعدة بيانات الشركات المصنعة (OUI Database)
        self.oui_database = self._load_oui_database()
    
    def _load_oui_database(self):
        """تحميل قاعدة بيانات الشركات المصنعة للـ MAC addresses"""
        # قاعدة بيانات مبسطة للشركات المصنعة الشائعة
        return {
            '00:50:56': 'VMware',
            '08:00:27': 'VirtualBox',
            '00:0C:29': 'VMware',
            '00:1B:21': 'Intel',
            '00:1F:3C': 'Apple',
            '00:23:12': 'Apple',
            '28:CF:E9': 'Apple',
            '3C:07:54': 'Apple',
            '40:A6:D9': 'Apple',
            '4C:32:75': 'Apple',
            '50:ED:3C': 'Apple',
            '58:55:CA': 'Apple',
            '5C:95:AE': 'Apple',
            '60:03:08': 'Apple',
            '60:C5:47': 'Apple',
            '64:20:0C': 'Apple',
            '68:AB:1E': 'Apple',
            '6C:40:08': 'Apple',
            '70:56:81': 'Apple',
            '78:4F:43': 'Apple',
            '7C:6D:62': 'Apple',
            '80:E6:50': 'Apple',
            '84:38:35': 'Apple',
            '88:63:DF': 'Apple',
            '8C:85:90': 'Apple',
            '90:72:40': 'Apple',
            '98:01:A7': 'Apple',
            '9C:FC:E8': 'Apple',
            'A4:5E:60': 'Apple',
            'A8:86:DD': 'Apple',
            'AC:87:A3': 'Apple',
            'B0:65:BD': 'Apple',
            'B4:18:D1': 'Apple',
            'B8:09:8A': 'Apple',
            'B8:C7:5D': 'Apple',
            'BC:52:B7': 'Apple',
            'C0:CC:F8': 'Apple',
            'C4:B3:01': 'Apple',
            'C8:BC:C8': 'Apple',
            'CC:25:EF': 'Apple',
            'D0:03:4B': 'Apple',
            'D4:9A:20': 'Apple',
            'D8:30:62': 'Apple',
            'D8:A2:5E': 'Apple',
            'DC:2B:2A': 'Apple',
            'E0:AC:CB': 'Apple',
            'E4:CE:8F': 'Apple',
            'E8:8D:28': 'Apple',
            'EC:35:86': 'Apple',
            'F0:18:98': 'Apple',
            'F4:0F:24': 'Apple',
            'F8:1E:DF': 'Apple',
            'FC:25:3F': 'Apple',
            # Samsung
            '00:12:FB': 'Samsung',
            '00:15:99': 'Samsung',
            '00:16:32': 'Samsung',
            '00:17:C9': 'Samsung',
            '00:1A:8A': 'Samsung',
            '00:1D:25': 'Samsung',
            '00:1E:7D': 'Samsung',
            '00:21:19': 'Samsung',
            '00:23:39': 'Samsung',
            '00:26:37': 'Samsung',
            '08:EC:A9': 'Samsung',
            '10:30:47': 'Samsung',
            '18:3A:2D': 'Samsung',
            '1C:62:B8': 'Samsung',
            '20:64:32': 'Samsung',
            '28:39:26': 'Samsung',
            '2C:44:01': 'Samsung',
            '34:23:87': 'Samsung',
            '38:AA:3C': 'Samsung',
            '40:0E:85': 'Samsung',
            '44:4E:6D': 'Samsung',
            '48:44:F7': 'Samsung',
            '4C:3C:16': 'Samsung',
            '50:32:37': 'Samsung',
            '54:88:0E': 'Samsung',
            '58:21:EF': 'Samsung',
            '5C:0A:5B': 'Samsung',
            '60:6B:BD': 'Samsung',
            '64:B8:53': 'Samsung',
            '68:EB:C5': 'Samsung',
            '6C:2F:2C': 'Samsung',
            '70:F9:27': 'Samsung',
            '74:45:CE': 'Samsung',
            '78:1F:DB': 'Samsung',
            '7C:61:66': 'Samsung',
            '80:57:19': 'Samsung',
            '84:25:3F': 'Samsung',
            '88:32:9B': 'Samsung',
            '8C:77:12': 'Samsung',
            '90:18:7C': 'Samsung',
            '94:35:0A': 'Samsung',
            '98:22:EF': 'Samsung',
            '9C:02:98': 'Samsung',
            'A0:0B:BA': 'Samsung',
            'A4:EB:D3': 'Samsung',
            'A8:F2:74': 'Samsung',
            'AC:36:13': 'Samsung',
            'B0:EC:71': 'Samsung',
            'B4:62:93': 'Samsung',
            'B8:5E:7B': 'Samsung',
            'BC:85:1F': 'Samsung',
            'C0:BD:D1': 'Samsung',
            'C4:57:6E': 'Samsung',
            'C8:BA:94': 'Samsung',
            'CC:07:AB': 'Samsung',
            'D0:22:BE': 'Samsung',
            'D4:87:D8': 'Samsung',
            'D8:90:E8': 'Samsung',
            'DC:71:96': 'Samsung',
            'E0:91:F5': 'Samsung',
            'E4:40:E2': 'Samsung',
            'E8:50:8B': 'Samsung',
            'EC:1F:72': 'Samsung',
            'F0:25:B7': 'Samsung',
            'F4:09:D8': 'Samsung',
            'F8:04:2E': 'Samsung',
            'FC:A6:21': 'Samsung',
            # TP-Link
            '14:CC:20': 'TP-Link',
            '50:C7:BF': 'TP-Link',
            '60:E3:27': 'TP-Link',
            '64:70:02': 'TP-Link',
            '74:DA:38': 'TP-Link',
            '98:DA:C4': 'TP-Link',
            'A0:F3:C1': 'TP-Link',
            'B0:95:75': 'TP-Link',
            'C0:4A:00': 'TP-Link',
            'E8:DE:27': 'TP-Link',
            'F4:F2:6D': 'TP-Link',
            # D-Link
            '00:05:5D': 'D-Link',
            '00:0F:3D': 'D-Link',
            '00:11:95': 'D-Link',
            '00:13:46': 'D-Link',
            '00:15:E9': 'D-Link',
            '00:17:9A': 'D-Link',
            '00:19:5B': 'D-Link',
            '00:1B:11': 'D-Link',
            '00:1C:F0': 'D-Link',
            '00:1E:58': 'D-Link',
            '00:21:91': 'D-Link',
            '00:22:B0': 'D-Link',
            '00:24:01': 'D-Link',
            '00:26:5A': 'D-Link',
            '14:D6:4D': 'D-Link',
            '1C:7E:E5': 'D-Link',
            '28:10:7B': 'D-Link',
            '2C:B0:5D': 'D-Link',
            '34:08:04': 'D-Link',
            '40:61:86': 'D-Link',
            '5C:D9:98': 'D-Link',
            '78:54:2E': 'D-Link',
            '84:C9:B2': 'D-Link',
            '90:94:E4': 'D-Link',
            'B0:C5:54': 'D-Link',
            'C8:BE:19': 'D-Link',
            'CC:B2:55': 'D-Link',
            'E4:6F:13': 'D-Link',
            'F0:7D:68': 'D-Link'
        }
    
    def get_network_info(self):
        """الحصول على معلومات الشبكة المحلية"""
        try:
            # الحصول على الـ IP المحلي
            hostname = socket.gethostname()
            self.local_ip = socket.gethostbyname(hostname)
            
            # الحصول على Gateway IP
            if hasattr(psutil, 'net_if_addrs'):
                # استخدام psutil للحصول على معلومات الشبكة
                for interface_name, interface_addresses in psutil.net_if_addrs().items():
                    for address in interface_addresses:
                        if address.family == socket.AF_INET and not address.address.startswith('127.'):
                            self.local_ip = address.address
                            # حساب الشبكة المحلية
                            if address.netmask:
                                network = ipaddress.IPv4Network(f"{address.address}/{address.netmask}", strict=False)
                                self.local_network = network
                            break
                    if self.local_network:
                        break
            
            # محاولة الحصول على Gateway IP
            self.gateway_ip = self._get_gateway_ip()
            
            return {
                'local_ip': self.local_ip,
                'gateway_ip': self.gateway_ip,
                'network': str(self.local_network) if self.local_network else None
            }
            
        except Exception as e:
            print(f"خطأ في الحصول على معلومات الشبكة: {e}")
            return None
    
    def _get_gateway_ip(self):
        """الحصول على عنوان Gateway"""
        try:
            # محاولة استخدام route command
            result = subprocess.run(['ip', 'route', 'show', 'default'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                # البحث عن Gateway IP في النتيجة
                match = re.search(r'default via (\d+\.\d+\.\d+\.\d+)', result.stdout)
                if match:
                    return match.group(1)
        except:
            pass
        
        try:
            # محاولة بديلة باستخدام netstat
            result = subprocess.run(['netstat', '-rn'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                lines = result.stdout.split('\n')
                for line in lines:
                    if '0.0.0.0' in line or 'default' in line:
                        parts = line.split()
                        for part in parts:
                            if re.match(r'\d+\.\d+\.\d+\.\d+', part) and not part.startswith('0.0.0.0'):
                                return part
        except:
            pass
        
        return None
    
    def start_network_scan(self):
        """بدء مسح الشبكة"""
        if self.is_scanning:
            return False
        
        # الحصول على معلومات الشبكة أولاً
        network_info = self.get_network_info()
        if not network_info or not self.local_network:
            return False
        
        self.is_scanning = True
        self.discovered_devices.clear()
        
        # بدء خيط المسح
        self.scan_thread = threading.Thread(target=self._scan_network)
        self.scan_thread.daemon = True
        self.scan_thread.start()
        
        return True
    
    def stop_network_scan(self):
        """إيقاف مسح الشبكة"""
        self.is_scanning = False
        if self.scan_thread and self.scan_thread.is_alive():
            self.scan_thread.join(timeout=5)
    
    def _scan_network(self):
        """مسح الشبكة (يعمل في خيط منفصل)"""
        try:
            if not self.local_network:
                return
            
            # الحصول على قائمة الـ IP addresses في الشبكة
            network_hosts = list(self.local_network.hosts())
            total_hosts = len(network_hosts)
            
            # مسح كل IP في الشبكة
            for i, ip in enumerate(network_hosts):
                if not self.is_scanning:
                    break
                
                # تحديث تقدم المسح
                progress = int((i + 1) / total_hosts * 100)
                self.scan_progress.emit(progress)
                
                # فحص الـ IP
                device_info = self._scan_host(str(ip))
                if device_info:
                    self.discovered_devices.append(device_info)
                    self.device_discovered.emit(device_info)
            
            # إرسال إشارة اكتمال المسح
            self.scan_completed.emit(self.discovered_devices)
            
        except Exception as e:
            print(f"خطأ في مسح الشبكة: {e}")
        finally:
            self.is_scanning = False
    
    def _scan_host(self, ip_address):
        """فحص host محدد"""
        try:
            # ping test
            if not self._ping_host(ip_address):
                return None
            
            device_info = {
                'ip': ip_address,
                'hostname': '',
                'mac_address': '',
                'vendor': '',
                'device_type': 'Unknown',
                'status': 'Online',
                'response_time': 0,
                'open_ports': [],
                'last_seen': time.time()
            }
            
            # الحصول على hostname
            device_info['hostname'] = self._get_hostname(ip_address)
            
            # الحصول على MAC address
            device_info['mac_address'] = self._get_mac_address(ip_address)
            
            # تحديد الشركة المصنعة
            if device_info['mac_address']:
                device_info['vendor'] = self._get_vendor_from_mac(device_info['mac_address'])
            
            # تحديد نوع الجهاز
            device_info['device_type'] = self._identify_device_type(device_info)
            
            # فحص المنافذ المفتوحة (فحص سريع للمنافذ الشائعة)
            device_info['open_ports'] = self._scan_common_ports(ip_address)
            
            return device_info
            
        except Exception as e:
            print(f"خطأ في فحص {ip_address}: {e}")
            return None
    
    def _ping_host(self, ip_address, timeout=1):
        """ping test للتحقق من وجود الجهاز"""
        try:
            result = subprocess.run(
                ['ping', '-c', '1', '-W', str(timeout), ip_address],
                capture_output=True,
                timeout=timeout + 1
            )
            return result.returncode == 0
        except:
            return False
    
    def _get_hostname(self, ip_address):
        """الحصول على hostname للجهاز"""
        try:
            hostname = socket.gethostbyaddr(ip_address)[0]
            return hostname
        except:
            return ''
    
    def _get_mac_address(self, ip_address):
        """الحصول على MAC address للجهاز"""
        try:
            # استخدام ARP table
            result = subprocess.run(['arp', '-n', ip_address], 
                                  capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                # البحث عن MAC address في النتيجة
                match = re.search(r'([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}', result.stdout)
                if match:
                    return match.group(0).upper()
        except:
            pass
        
        return ''
    
    def _get_vendor_from_mac(self, mac_address):
        """تحديد الشركة المصنعة من MAC address"""
        if not mac_address:
            return 'Unknown'
        
        # استخراج OUI (أول 3 bytes)
        oui = mac_address[:8].replace(':', '').replace('-', '')[:6]
        oui_formatted = ':'.join([oui[i:i+2] for i in range(0, 6, 2)]).upper()
        
        return self.oui_database.get(oui_formatted, 'Unknown')
    
    def _identify_device_type(self, device_info):
        """تحديد نوع الجهاز بناءً على المعلومات المتاحة"""
        hostname = device_info.get('hostname', '').lower()
        vendor = device_info.get('vendor', '').lower()
        ip = device_info.get('ip', '')
        
        # Router/Gateway
        if ip == self.gateway_ip:
            return 'Router/Gateway'
        
        # تحديد النوع بناءً على hostname
        if any(keyword in hostname for keyword in ['router', 'gateway', 'modem']):
            return 'Router'
        elif any(keyword in hostname for keyword in ['phone', 'mobile', 'android', 'iphone']):
            return 'Mobile Device'
        elif any(keyword in hostname for keyword in ['laptop', 'pc', 'desktop', 'computer']):
            return 'Computer'
        elif any(keyword in hostname for keyword in ['printer', 'print']):
            return 'Printer'
        elif any(keyword in hostname for keyword in ['tv', 'smart', 'media']):
            return 'Smart TV/Media Device'
        
        # تحديد النوع بناءً على الشركة المصنعة
        if 'apple' in vendor:
            return 'Apple Device'
        elif 'samsung' in vendor:
            return 'Samsung Device'
        elif any(router_vendor in vendor for router_vendor in ['tp-link', 'd-link', 'netgear', 'linksys']):
            return 'Network Equipment'
        
        return 'Unknown Device'
    
    def _scan_common_ports(self, ip_address, timeout=0.5):
        """فحص المنافذ الشائعة"""
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 8080, 8443]
        open_ports = []
        
        for port in common_ports:
            if not self.is_scanning:
                break
                
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                result = sock.connect_ex((ip_address, port))
                sock.close()
                
                if result == 0:
                    open_ports.append(port)
            except:
                pass
        
        return open_ports
    
    def get_discovered_devices(self):
        """الحصول على قائمة الأجهزة المكتشفة"""
        return self.discovered_devices.copy()
    
    def refresh_device_info(self, ip_address):
        """تحديث معلومات جهاز محدد"""
        device_info = self._scan_host(ip_address)
        if device_info:
            # تحديث الجهاز في القائمة
            for i, device in enumerate(self.discovered_devices):
                if device['ip'] == ip_address:
                    self.discovered_devices[i] = device_info
                    break
            else:
                # إضافة جهاز جديد
                self.discovered_devices.append(device_info)
            
            self.device_discovered.emit(device_info)
        
        return device_info
    
    def is_device_online(self, ip_address):
        """التحقق من حالة الجهاز (متصل/غير متصل)"""
        return self._ping_host(ip_address)
    
    def get_network_statistics(self):
        """الحصول على إحصائيات الشبكة"""
        online_devices = len([d for d in self.discovered_devices if d['status'] == 'Online'])
        
        device_types = {}
        vendors = {}
        
        for device in self.discovered_devices:
            device_type = device.get('device_type', 'Unknown')
            vendor = device.get('vendor', 'Unknown')
            
            device_types[device_type] = device_types.get(device_type, 0) + 1
            vendors[vendor] = vendors.get(vendor, 0) + 1
        
        return {
            'total_devices': len(self.discovered_devices),
            'online_devices': online_devices,
            'offline_devices': len(self.discovered_devices) - online_devices,
            'device_types': device_types,
            'vendors': vendors,
            'network_range': str(self.local_network) if self.local_network else 'Unknown',
            'gateway_ip': self.gateway_ip,
            'local_ip': self.local_ip
        }

