#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Main Window
واجهة المستخدم الرئيسية لتطبيق حماية الشبكات
"""

import sys
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QTabWidget, QLabel, QPushButton, QTextEdit, 
                             QTableWidget, QTableWidgetItem, QProgressBar,
                             QGroupBox, QGridLayout, QFrame, QSplitter,
                             QMenuBar, QStatusBar, QAction, QMessageBox,
                             QComboBox, QCheckBox, QSpinBox)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFont, QIcon, QPalette, QColor

class NetworkProtectorMainWindow(QMainWindow):
    """النافذة الرئيسية لتطبيق حماية الشبكات"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.setup_connections()
        self.apply_dark_theme()
        
    def init_ui(self):
        """إعداد واجهة المستخدم"""
        self.setWindowTitle("Network Protector - حماية الشبكات")
        self.setGeometry(100, 100, 1200, 800)
        self.setMinimumSize(800, 600)
        
        # إنشاء القائمة الرئيسية
        self.create_menu_bar()
        
        # إنشاء شريط الحالة
        self.create_status_bar()
        
        # إنشاء الواجهة المركزية
        self.create_central_widget()
        
    def create_menu_bar(self):
        """إنشاء شريط القوائم"""
        menubar = self.menuBar()
        
        # قائمة الملف
        file_menu = menubar.addMenu('ملف')
        
        # إعدادات
        settings_action = QAction('الإعدادات', self)
        settings_action.setShortcut('Ctrl+S')
        settings_action.triggered.connect(self.open_settings)
        file_menu.addAction(settings_action)
        
        file_menu.addSeparator()
        
        # خروج
        exit_action = QAction('خروج', self)
        exit_action.setShortcut('Ctrl+Q')
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # قائمة العرض
        view_menu = menubar.addMenu('عرض')
        
        # الوضع الليلي
        self.dark_mode_action = QAction('الوضع الليلي', self)
        self.dark_mode_action.setCheckable(True)
        self.dark_mode_action.setChecked(True)
        self.dark_mode_action.triggered.connect(self.toggle_dark_mode)
        view_menu.addAction(self.dark_mode_action)
        
        # وضع المبتدئ/المتقدم
        self.advanced_mode_action = QAction('الوضع المتقدم', self)
        self.advanced_mode_action.setCheckable(True)
        self.advanced_mode_action.triggered.connect(self.toggle_advanced_mode)
        view_menu.addAction(self.advanced_mode_action)
        
        # قائمة المساعدة
        help_menu = menubar.addMenu('مساعدة')
        
        about_action = QAction('حول البرنامج', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
    def create_status_bar(self):
        """إنشاء شريط الحالة"""
        self.status_bar = self.statusBar()
        
        # حالة الاتصال
        self.connection_status = QLabel("غير متصل")
        self.connection_status.setStyleSheet("color: red; font-weight: bold;")
        self.status_bar.addWidget(self.connection_status)
        
        # عداد الحزم
        self.packet_counter = QLabel("الحزم: 0")
        self.status_bar.addPermanentWidget(self.packet_counter)
        
        # حالة الحماية
        self.protection_status = QLabel("الحماية: متوقفة")
        self.protection_status.setStyleSheet("color: orange; font-weight: bold;")
        self.status_bar.addPermanentWidget(self.protection_status)
        
    def create_central_widget(self):
        """إنشاء الواجهة المركزية"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # التخطيط الرئيسي
        main_layout = QVBoxLayout(central_widget)
        
        # شريط التحكم العلوي
        control_bar = self.create_control_bar()
        main_layout.addWidget(control_bar)
        
        # التبويبات الرئيسية
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)
        
        # تبويب لوحة التحكم
        self.create_dashboard_tab()
        
        # تبويب خريطة الشبكة
        self.create_network_map_tab()
        
        # تبويب مراقبة الحركة
        self.create_traffic_monitor_tab()
        
        # تبويب كشف التهديدات
        self.create_threat_detection_tab()
        
        # تبويب التحكم في الراوتر
        self.create_router_control_tab()
        
        # تبويب الإحصائيات
        self.create_statistics_tab()
        
        # تبويب السجلات
        self.create_logs_tab()
        
    def create_control_bar(self):
        """إنشاء شريط التحكم العلوي"""
        control_frame = QFrame()
        control_frame.setFrameStyle(QFrame.StyledPanel)
        control_frame.setMaximumHeight(80)
        
        layout = QHBoxLayout(control_frame)
        
        # زر بدء/إيقاف المراقبة
        self.start_stop_btn = QPushButton("بدء المراقبة")
        self.start_stop_btn.setMinimumSize(120, 40)
        self.start_stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
        """)
        self.start_stop_btn.clicked.connect(self.toggle_monitoring)
        layout.addWidget(self.start_stop_btn)
        
        # زر الحماية التلقائية
        self.auto_protect_btn = QPushButton("تفعيل الحماية التلقائية")
        self.auto_protect_btn.setMinimumSize(150, 40)
        self.auto_protect_btn.setCheckable(True)
        self.auto_protect_btn.clicked.connect(self.toggle_auto_protection)
        layout.addWidget(self.auto_protect_btn)
        
        # مؤشر الحالة
        status_group = QGroupBox("حالة النظام")
        status_layout = QGridLayout(status_group)
        
        self.network_status_indicator = QLabel("●")
        self.network_status_indicator.setStyleSheet("color: red; font-size: 20px;")
        status_layout.addWidget(QLabel("الشبكة:"), 0, 0)
        status_layout.addWidget(self.network_status_indicator, 0, 1)
        
        self.protection_indicator = QLabel("●")
        self.protection_indicator.setStyleSheet("color: orange; font-size: 20px;")
        status_layout.addWidget(QLabel("الحماية:"), 1, 0)
        status_layout.addWidget(self.protection_indicator, 1, 1)
        
        layout.addWidget(status_group)
        
        layout.addStretch()
        
        # اختيار اللغة
        language_combo = QComboBox()
        language_combo.addItems(["العربية", "English"])
        language_combo.currentTextChanged.connect(self.change_language)
        layout.addWidget(QLabel("اللغة:"))
        layout.addWidget(language_combo)
        
        return control_frame
        
    def create_dashboard_tab(self):
        """إنشاء تبويب لوحة التحكم"""
        dashboard_widget = QWidget()
        layout = QGridLayout(dashboard_widget)
        
        # إحصائيات سريعة
        stats_group = QGroupBox("إحصائيات سريعة")
        stats_layout = QGridLayout(stats_group)
        
        # عدد الأجهزة المتصلة
        self.connected_devices_label = QLabel("0")
        self.connected_devices_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #2196F3;")
        stats_layout.addWidget(QLabel("الأجهزة المتصلة:"), 0, 0)
        stats_layout.addWidget(self.connected_devices_label, 0, 1)
        
        # التهديدات المكتشفة
        self.threats_detected_label = QLabel("0")
        self.threats_detected_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #F44336;")
        stats_layout.addWidget(QLabel("التهديدات المكتشفة:"), 1, 0)
        stats_layout.addWidget(self.threats_detected_label, 1, 1)
        
        # سرعة الشبكة
        self.network_speed_label = QLabel("0 Mbps")
        self.network_speed_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #4CAF50;")
        stats_layout.addWidget(QLabel("سرعة الشبكة:"), 2, 0)
        stats_layout.addWidget(self.network_speed_label, 2, 1)
        
        layout.addWidget(stats_group, 0, 0)
        
        # التنبيهات الأخيرة
        alerts_group = QGroupBox("التنبيهات الأخيرة")
        alerts_layout = QVBoxLayout(alerts_group)
        
        self.alerts_text = QTextEdit()
        self.alerts_text.setMaximumHeight(200)
        self.alerts_text.setReadOnly(True)
        alerts_layout.addWidget(self.alerts_text)
        
        layout.addWidget(alerts_group, 0, 1)
        
        # رسم بياني للحركة
        traffic_group = QGroupBox("حركة الشبكة")
        traffic_layout = QVBoxLayout(traffic_group)
        
        # هنا سيتم إضافة الرسم البياني لاحقاً
        traffic_placeholder = QLabel("سيتم إضافة الرسم البياني هنا")
        traffic_placeholder.setAlignment(Qt.AlignCenter)
        traffic_placeholder.setMinimumHeight(200)
        traffic_placeholder.setStyleSheet("border: 2px dashed #666; color: #666;")
        traffic_layout.addWidget(traffic_placeholder)
        
        layout.addWidget(traffic_group, 1, 0, 1, 2)
        
        self.tab_widget.addTab(dashboard_widget, "لوحة التحكم")
        
    def create_network_map_tab(self):
        """إنشاء تبويب خريطة الشبكة"""
        network_map_widget = QWidget()
        layout = QVBoxLayout(network_map_widget)
        
        # جدول الأجهزة المتصلة
        self.devices_table = QTableWidget()
        self.devices_table.setColumnCount(5)
        self.devices_table.setHorizontalHeaderLabels([
            "اسم الجهاز", "عنوان IP", "عنوان MAC", "الشركة المصنعة", "الحالة"
        ])
        
        # إضافة بيانات تجريبية
        self.devices_table.setRowCount(3)
        sample_data = [
            ["Router", "192.168.1.1", "AA:BB:CC:DD:EE:FF", "TP-Link", "متصل"],
            ["Laptop", "192.168.1.100", "11:22:33:44:55:66", "Dell", "متصل"],
            ["Phone", "192.168.1.101", "77:88:99:AA:BB:CC", "Samsung", "متصل"]
        ]
        
        for row, data in enumerate(sample_data):
            for col, value in enumerate(data):
                self.devices_table.setItem(row, col, QTableWidgetItem(value))
        
        layout.addWidget(self.devices_table)
        
        # أزرار التحكم
        buttons_layout = QHBoxLayout()
        
        refresh_btn = QPushButton("تحديث")
        refresh_btn.clicked.connect(self.refresh_network_map)
        buttons_layout.addWidget(refresh_btn)
        
        block_device_btn = QPushButton("حظر الجهاز المحدد")
        block_device_btn.clicked.connect(self.block_selected_device)
        buttons_layout.addWidget(block_device_btn)
        
        buttons_layout.addStretch()
        layout.addLayout(buttons_layout)
        
        self.tab_widget.addTab(network_map_widget, "خريطة الشبكة")
        
    def create_traffic_monitor_tab(self):
        """إنشاء تبويب مراقبة الحركة"""
        traffic_widget = QWidget()
        layout = QVBoxLayout(traffic_widget)
        
        # معلومات الحركة
        info_group = QGroupBox("معلومات الحركة")
        info_layout = QGridLayout(info_group)
        
        self.packets_received_label = QLabel("0")
        info_layout.addWidget(QLabel("الحزم المستلمة:"), 0, 0)
        info_layout.addWidget(self.packets_received_label, 0, 1)
        
        self.packets_sent_label = QLabel("0")
        info_layout.addWidget(QLabel("الحزم المرسلة:"), 1, 0)
        info_layout.addWidget(self.packets_sent_label, 1, 1)
        
        self.data_received_label = QLabel("0 MB")
        info_layout.addWidget(QLabel("البيانات المستلمة:"), 0, 2)
        info_layout.addWidget(self.data_received_label, 0, 3)
        
        self.data_sent_label = QLabel("0 MB")
        info_layout.addWidget(QLabel("البيانات المرسلة:"), 1, 2)
        info_layout.addWidget(self.data_sent_label, 1, 3)
        
        layout.addWidget(info_group)
        
        # سجل الحزم
        packets_group = QGroupBox("سجل الحزم")
        packets_layout = QVBoxLayout(packets_group)
        
        self.packets_log = QTextEdit()
        self.packets_log.setReadOnly(True)
        self.packets_log.setFont(QFont("Courier", 9))
        packets_layout.addWidget(self.packets_log)
        
        layout.addWidget(packets_group)
        
        self.tab_widget.addTab(traffic_widget, "مراقبة الحركة")
        
    def create_threat_detection_tab(self):
        """إنشاء تبويب كشف التهديدات"""
        threat_widget = QWidget()
        layout = QVBoxLayout(threat_widget)
        
        # إعدادات الكشف
        detection_settings_group = QGroupBox("إعدادات الكشف")
        settings_layout = QGridLayout(detection_settings_group)
        
        # تفعيل أنواع الكشف المختلفة
        self.ddos_detection_cb = QCheckBox("كشف هجمات DDoS")
        self.ddos_detection_cb.setChecked(True)
        settings_layout.addWidget(self.ddos_detection_cb, 0, 0)
        
        self.mitm_detection_cb = QCheckBox("كشف هجمات MITM")
        self.mitm_detection_cb.setChecked(True)
        settings_layout.addWidget(self.mitm_detection_cb, 0, 1)
        
        self.spoofing_detection_cb = QCheckBox("كشف هجمات Spoofing")
        self.spoofing_detection_cb.setChecked(True)
        settings_layout.addWidget(self.spoofing_detection_cb, 1, 0)
        
        self.port_scan_detection_cb = QCheckBox("كشف Port Scanning")
        self.port_scan_detection_cb.setChecked(True)
        settings_layout.addWidget(self.port_scan_detection_cb, 1, 1)
        
        # حساسية الكشف
        sensitivity_label = QLabel("حساسية الكشف:")
        settings_layout.addWidget(sensitivity_label, 2, 0)
        
        self.sensitivity_combo = QComboBox()
        self.sensitivity_combo.addItems(["منخفضة", "متوسطة", "عالية"])
        self.sensitivity_combo.setCurrentText("متوسطة")
        settings_layout.addWidget(self.sensitivity_combo, 2, 1)
        
        layout.addWidget(detection_settings_group)
        
        # سجل التهديدات
        threats_group = QGroupBox("سجل التهديدات المكتشفة")
        threats_layout = QVBoxLayout(threats_group)
        
        self.threats_table = QTableWidget()
        self.threats_table.setColumnCount(5)
        self.threats_table.setHorizontalHeaderLabels([
            "الوقت", "نوع التهديد", "المصدر", "الهدف", "الإجراء المتخذ"
        ])
        threats_layout.addWidget(self.threats_table)
        
        layout.addWidget(threats_group)
        
        self.tab_widget.addTab(threat_widget, "كشف التهديدات")
        
    def create_router_control_tab(self):
        """إنشاء تبويب التحكم في الراوتر"""
        router_widget = QWidget()
        layout = QVBoxLayout(router_widget)
        
        # معلومات الراوتر
        router_info_group = QGroupBox("معلومات الراوتر")
        info_layout = QGridLayout(router_info_group)
        
        self.router_ip_label = QLabel("غير محدد")
        info_layout.addWidget(QLabel("عنوان IP للراوتر:"), 0, 0)
        info_layout.addWidget(self.router_ip_label, 0, 1)
        
        self.router_model_label = QLabel("غير محدد")
        info_layout.addWidget(QLabel("موديل الراوتر:"), 1, 0)
        info_layout.addWidget(self.router_model_label, 1, 1)
        
        # زر الاتصال بالراوتر
        connect_router_btn = QPushButton("الاتصال بالراوتر")
        connect_router_btn.clicked.connect(self.connect_to_router)
        info_layout.addWidget(connect_router_btn, 0, 2)
        
        layout.addWidget(router_info_group)
        
        # إعدادات الشبكة
        network_settings_group = QGroupBox("إعدادات الشبكة")
        network_layout = QGridLayout(network_settings_group)
        
        # تغيير كلمة مرور WiFi
        network_layout.addWidget(QLabel("كلمة مرور WiFi الجديدة:"), 0, 0)
        self.wifi_password_input = QTextEdit()
        self.wifi_password_input.setMaximumHeight(30)
        network_layout.addWidget(self.wifi_password_input, 0, 1)
        
        change_password_btn = QPushButton("تغيير كلمة المرور")
        change_password_btn.clicked.connect(self.change_wifi_password)
        network_layout.addWidget(change_password_btn, 0, 2)
        
        # إعادة تشغيل الراوتر
        restart_router_btn = QPushButton("إعادة تشغيل الراوتر")
        restart_router_btn.clicked.connect(self.restart_router)
        network_layout.addWidget(restart_router_btn, 1, 0)
        
        layout.addWidget(network_settings_group)
        
        # التحكم في الأجهزة
        device_control_group = QGroupBox("التحكم في الأجهزة")
        device_layout = QVBoxLayout(device_control_group)
        
        # جدول الأجهزة مع إعدادات السرعة
        self.device_control_table = QTableWidget()
        self.device_control_table.setColumnCount(4)
        self.device_control_table.setHorizontalHeaderLabels([
            "الجهاز", "عنوان IP", "حد السرعة (Mbps)", "حالة الاتصال"
        ])
        device_layout.addWidget(self.device_control_table)
        
        layout.addWidget(device_control_group)
        
        self.tab_widget.addTab(router_widget, "التحكم في الراوتر")
        
    def create_statistics_tab(self):
        """إنشاء تبويب الإحصائيات"""
        stats_widget = QWidget()
        layout = QVBoxLayout(stats_widget)
        
        # فترة الإحصائيات
        period_group = QGroupBox("فترة الإحصائيات")
        period_layout = QHBoxLayout(period_group)
        
        period_combo = QComboBox()
        period_combo.addItems(["آخر ساعة", "آخر 24 ساعة", "آخر أسبوع", "آخر شهر"])
        period_layout.addWidget(QLabel("الفترة:"))
        period_layout.addWidget(period_combo)
        period_layout.addStretch()
        
        layout.addWidget(period_group)
        
        # الرسوم البيانية
        charts_group = QGroupBox("الرسوم البيانية")
        charts_layout = QVBoxLayout(charts_group)
        
        # هنا سيتم إضافة الرسوم البيانية لاحقاً
        charts_placeholder = QLabel("سيتم إضافة الرسوم البيانية هنا")
        charts_placeholder.setAlignment(Qt.AlignCenter)
        charts_placeholder.setMinimumHeight(400)
        charts_placeholder.setStyleSheet("border: 2px dashed #666; color: #666;")
        charts_layout.addWidget(charts_placeholder)
        
        layout.addWidget(charts_group)
        
        self.tab_widget.addTab(stats_widget, "الإحصائيات")
        
    def create_logs_tab(self):
        """إنشاء تبويب السجلات"""
        logs_widget = QWidget()
        layout = QVBoxLayout(logs_widget)
        
        # فلاتر السجلات
        filters_group = QGroupBox("فلاتر السجلات")
        filters_layout = QHBoxLayout(filters_group)
        
        log_level_combo = QComboBox()
        log_level_combo.addItems(["جميع المستويات", "معلومات", "تحذيرات", "أخطاء"])
        filters_layout.addWidget(QLabel("مستوى السجل:"))
        filters_layout.addWidget(log_level_combo)
        
        date_combo = QComboBox()
        date_combo.addItems(["اليوم", "أمس", "آخر أسبوع", "آخر شهر"])
        filters_layout.addWidget(QLabel("التاريخ:"))
        filters_layout.addWidget(date_combo)
        
        filters_layout.addStretch()
        
        clear_logs_btn = QPushButton("مسح السجلات")
        clear_logs_btn.clicked.connect(self.clear_logs)
        filters_layout.addWidget(clear_logs_btn)
        
        layout.addWidget(filters_group)
        
        # عرض السجلات
        self.logs_text = QTextEdit()
        self.logs_text.setReadOnly(True)
        self.logs_text.setFont(QFont("Courier", 9))
        layout.addWidget(self.logs_text)
        
        self.tab_widget.addTab(logs_widget, "السجلات")
        
    def setup_connections(self):
        """إعداد الاتصالات والإشارات"""
        # إعداد مؤقت لتحديث الواجهة
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_interface)
        self.update_timer.start(1000)  # تحديث كل ثانية
        
    def apply_dark_theme(self):
        """تطبيق الثيم الداكن"""
        dark_stylesheet = """
        QMainWindow {
            background-color: #2b2b2b;
            color: #ffffff;
        }
        QWidget {
            background-color: #2b2b2b;
            color: #ffffff;
        }
        QTabWidget::pane {
            border: 1px solid #555555;
            background-color: #3c3c3c;
        }
        QTabBar::tab {
            background-color: #555555;
            color: #ffffff;
            padding: 8px 16px;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background-color: #0078d4;
        }
        QGroupBox {
            font-weight: bold;
            border: 2px solid #555555;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
        }
        QPushButton {
            background-color: #0078d4;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #106ebe;
        }
        QPushButton:pressed {
            background-color: #005a9e;
        }
        QTableWidget {
            background-color: #3c3c3c;
            alternate-background-color: #484848;
            gridline-color: #555555;
        }
        QHeaderView::section {
            background-color: #555555;
            color: #ffffff;
            padding: 4px;
            border: 1px solid #666666;
        }
        QTextEdit {
            background-color: #3c3c3c;
            border: 1px solid #555555;
        }
        QComboBox {
            background-color: #3c3c3c;
            border: 1px solid #555555;
            padding: 4px;
        }
        QComboBox::drop-down {
            border: none;
        }
        QComboBox::down-arrow {
            image: none;
            border-left: 5px solid transparent;
            border-right: 5px solid transparent;
            border-top: 5px solid #ffffff;
        }
        QCheckBox {
            spacing: 5px;
        }
        QCheckBox::indicator {
            width: 18px;
            height: 18px;
        }
        QCheckBox::indicator:unchecked {
            border: 2px solid #555555;
            background-color: #3c3c3c;
        }
        QCheckBox::indicator:checked {
            border: 2px solid #0078d4;
            background-color: #0078d4;
        }
        """
        self.setStyleSheet(dark_stylesheet)
        
    def toggle_monitoring(self):
        """تبديل حالة المراقبة"""
        if self.start_stop_btn.text() == "بدء المراقبة":
            self.start_stop_btn.setText("إيقاف المراقبة")
            self.start_stop_btn.setStyleSheet("""
                QPushButton {
                    background-color: #F44336;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    font-size: 14px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #da190b;
                }
            """)
            self.connection_status.setText("متصل")
            self.connection_status.setStyleSheet("color: green; font-weight: bold;")
            self.network_status_indicator.setStyleSheet("color: green; font-size: 20px;")
        else:
            self.start_stop_btn.setText("بدء المراقبة")
            self.start_stop_btn.setStyleSheet("""
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    font-size: 14px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #45a049;
                }
            """)
            self.connection_status.setText("غير متصل")
            self.connection_status.setStyleSheet("color: red; font-weight: bold;")
            self.network_status_indicator.setStyleSheet("color: red; font-size: 20px;")
            
    def toggle_auto_protection(self):
        """تبديل حالة الحماية التلقائية"""
        if self.auto_protect_btn.isChecked():
            self.auto_protect_btn.setText("إيقاف الحماية التلقائية")
            self.protection_status.setText("الحماية: نشطة")
            self.protection_status.setStyleSheet("color: green; font-weight: bold;")
            self.protection_indicator.setStyleSheet("color: green; font-size: 20px;")
        else:
            self.auto_protect_btn.setText("تفعيل الحماية التلقائية")
            self.protection_status.setText("الحماية: متوقفة")
            self.protection_status.setStyleSheet("color: orange; font-weight: bold;")
            self.protection_indicator.setStyleSheet("color: orange; font-size: 20px;")
            
    def update_interface(self):
        """تحديث الواجهة بشكل دوري"""
        # هنا سيتم إضافة منطق تحديث البيانات
        pass
        
    def open_settings(self):
        """فتح نافذة الإعدادات"""
        QMessageBox.information(self, "الإعدادات", "سيتم إضافة نافذة الإعدادات قريباً")
        
    def toggle_dark_mode(self):
        """تبديل الوضع الليلي"""
        if self.dark_mode_action.isChecked():
            self.apply_dark_theme()
        else:
            self.setStyleSheet("")  # إزالة الثيم الداكن
            
    def toggle_advanced_mode(self):
        """تبديل الوضع المتقدم"""
        # هنا سيتم إضافة منطق إظهار/إخفاء العناصر المتقدمة
        pass
        
    def show_about(self):
        """عرض معلومات حول البرنامج"""
        QMessageBox.about(self, "حول البرنامج", 
                         "Network Protector v1.0\n"
                         "تطبيق حماية الشبكات\n"
                         "تم التطوير باستخدام Python و PyQt5")
        
    def change_language(self, language):
        """تغيير لغة الواجهة"""
        # هنا سيتم إضافة منطق تغيير اللغة
        pass
        
    def refresh_network_map(self):
        """تحديث خريطة الشبكة"""
        QMessageBox.information(self, "تحديث", "تم تحديث خريطة الشبكة")
        
    def block_selected_device(self):
        """حظر الجهاز المحدد"""
        current_row = self.devices_table.currentRow()
        if current_row >= 0:
            device_name = self.devices_table.item(current_row, 0).text()
            QMessageBox.information(self, "حظر الجهاز", f"تم حظر الجهاز: {device_name}")
        else:
            QMessageBox.warning(self, "تحذير", "يرجى تحديد جهاز أولاً")
            
    def connect_to_router(self):
        """الاتصال بالراوتر"""
        QMessageBox.information(self, "الاتصال بالراوتر", "جاري الاتصال بالراوتر...")
        
    def change_wifi_password(self):
        """تغيير كلمة مرور WiFi"""
        new_password = self.wifi_password_input.toPlainText()
        if new_password:
            QMessageBox.information(self, "تغيير كلمة المرور", "تم تغيير كلمة مرور WiFi بنجاح")
        else:
            QMessageBox.warning(self, "تحذير", "يرجى إدخال كلمة مرور جديدة")
            
    def restart_router(self):
        """إعادة تشغيل الراوتر"""
        reply = QMessageBox.question(self, "إعادة تشغيل الراوتر", 
                                   "هل أنت متأكد من إعادة تشغيل الراوتر؟",
                                   QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, "إعادة التشغيل", "جاري إعادة تشغيل الراوتر...")
            
    def clear_logs(self):
        """مسح السجلات"""
        self.logs_text.clear()
        QMessageBox.information(self, "مسح السجلات", "تم مسح السجلات")

