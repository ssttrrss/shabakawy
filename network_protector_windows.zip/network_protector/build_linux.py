#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Linux Build Script
سكريپت بناء التطبيق لنظام Linux
"""

import os
import sys
import subprocess
import shutil
import tempfile
from pathlib import Path

def check_dependencies():
    """التحقق من المتطلبات"""
    dependencies = {
        'python3': 'python3 --version',
        'pip3': 'pip3 --version',
        'dpkg-deb': 'dpkg-deb --version',
        'rpmbuild': 'rpmbuild --version',
        'fpm': 'fpm --version'
    }
    
    available = {}
    for dep, cmd in dependencies.items():
        try:
            result = subprocess.run(cmd.split(), capture_output=True, text=True)
            available[dep] = result.returncode == 0
            if available[dep]:
                print(f"✓ {dep} متوفر")
            else:
                print(f"⚠ {dep} غير متوفر")
        except FileNotFoundError:
            available[dep] = False
            print(f"✗ {dep} غير مثبت")
    
    return available

def install_build_dependencies():
    """تثبيت متطلبات البناء"""
    try:
        # تثبيت PyInstaller
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyinstaller'])
        print("✓ تم تثبيت PyInstaller")
        
        # محاولة تثبيت fpm (لبناء الحزم)
        try:
            subprocess.check_call(['gem', 'install', 'fpm'])
            print("✓ تم تثبيت fpm")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("⚠ لم يتم تثبيت fpm - سيتم استخدام الطرق البديلة")
        
        return True
    except subprocess.CalledProcessError:
        print("✗ فشل في تثبيت المتطلبات")
        return False

def create_desktop_file():
    """إنشاء ملف .desktop"""
    desktop_content = '''[Desktop Entry]
Version=1.0
Type=Application
Name=Network Protector
Name[ar]=حماية الشبكات
Comment=Professional Network Security and Analysis Tool
Comment[ar]=أداة احترافية لحماية وتحليل الشبكات
Exec=/usr/bin/network-protector
Icon=network-protector
Terminal=false
StartupNotify=true
Categories=Network;Security;System;
Keywords=network;security;monitoring;firewall;
MimeType=application/x-pcap;
'''
    
    os.makedirs('packaging/linux', exist_ok=True)
    with open('packaging/linux/network-protector.desktop', 'w') as f:
        f.write(desktop_content)
    
    print("✓ تم إنشاء ملف .desktop")

def create_systemd_service():
    """إنشاء خدمة systemd"""
    service_content = '''[Unit]
Description=Network Protector Service
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/bin/network-protector --daemon
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
'''
    
    with open('packaging/linux/network-protector.service', 'w') as f:
        f.write(service_content)
    
    print("✓ تم إنشاء خدمة systemd")

def build_pyinstaller_binary():
    """بناء الملف التنفيذي باستخدام PyInstaller"""
    spec_content = '''# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['src/main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('assets', 'assets'),
        ('src/config', 'config'),
    ],
    hiddenimports=[
        'PyQt5.QtCore',
        'PyQt5.QtGui', 
        'PyQt5.QtWidgets',
        'scapy.all',
        'matplotlib.backends.backend_qt5agg',
        'pandas',
        'numpy',
        'requests',
        'psutil',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='network-protector',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
'''
    
    with open('network-protector.spec', 'w') as f:
        f.write(spec_content)
    
    try:
        subprocess.check_call(['pyinstaller', '--clean', '--noconfirm', 'network-protector.spec'])
        print("✓ تم بناء الملف التنفيذي بنجاح")
        return True
    except subprocess.CalledProcessError:
        print("✗ فشل في بناء الملف التنفيذي")
        return False

def create_deb_package():
    """إنشاء حزمة DEB"""
    try:
        # إنشاء هيكل الحزمة
        deb_dir = Path('packaging/deb')
        deb_dir.mkdir(parents=True, exist_ok=True)
        
        # إنشاء مجلدات DEBIAN
        debian_dir = deb_dir / 'DEBIAN'
        debian_dir.mkdir(exist_ok=True)
        
        # ملف control
        control_content = '''Package: network-protector
Version: 1.0.0
Section: net
Priority: optional
Architecture: amd64
Depends: python3 (>= 3.7), python3-pyqt5, libpcap0.8
Maintainer: Network Security Solutions <info@networksecurity.com>
Description: Professional Network Security and Analysis Tool
 Network Protector is a comprehensive network security and analysis tool
 that provides real-time network monitoring, threat detection, and router
 management capabilities.
 .
 Features include:
  - Real-time packet capture and analysis
  - Automatic threat detection (DDoS, MITM, Port Scanning)
  - Router configuration management
  - Network device discovery and mapping
  - Statistical analysis and reporting
  - Multi-language support (Arabic/English)
'''
        
        with open(debian_dir / 'control', 'w') as f:
            f.write(control_content)
        
        # سكريپت postinst
        postinst_content = '''#!/bin/bash
set -e

# Create application directory
mkdir -p /opt/network-protector

# Copy files
cp -r /tmp/network-protector-install/* /opt/network-protector/

# Create symlink
ln -sf /opt/network-protector/network-protector /usr/bin/network-protector

# Install desktop file
if [ -f /opt/network-protector/network-protector.desktop ]; then
    cp /opt/network-protector/network-protector.desktop /usr/share/applications/
    update-desktop-database
fi

# Install systemd service
if [ -f /opt/network-protector/network-protector.service ]; then
    cp /opt/network-protector/network-protector.service /etc/systemd/system/
    systemctl daemon-reload
fi

# Set permissions
chmod +x /opt/network-protector/network-protector
chmod +x /usr/bin/network-protector

echo "Network Protector installed successfully!"
echo "Run 'network-protector' to start the application."
'''
        
        with open(debian_dir / 'postinst', 'w') as f:
            f.write(postinst_content)
        os.chmod(debian_dir / 'postinst', 0o755)
        
        # سكريپت prerm
        prerm_content = '''#!/bin/bash
set -e

# Stop service if running
systemctl stop network-protector || true
systemctl disable network-protector || true

# Remove systemd service
rm -f /etc/systemd/system/network-protector.service
systemctl daemon-reload

# Remove desktop file
rm -f /usr/share/applications/network-protector.desktop
update-desktop-database

# Remove symlink
rm -f /usr/bin/network-protector
'''
        
        with open(debian_dir / 'prerm', 'w') as f:
            f.write(prerm_content)
        os.chmod(debian_dir / 'prerm', 0o755)
        
        # نسخ الملفات
        install_dir = deb_dir / 'tmp' / 'network-protector-install'
        install_dir.mkdir(parents=True, exist_ok=True)
        
        # نسخ الملف التنفيذي
        if os.path.exists('dist/network-protector'):
            shutil.copy2('dist/network-protector', install_dir)
        
        # نسخ الملفات الإضافية
        if os.path.exists('packaging/linux/network-protector.desktop'):
            shutil.copy2('packaging/linux/network-protector.desktop', install_dir)
        
        if os.path.exists('packaging/linux/network-protector.service'):
            shutil.copy2('packaging/linux/network-protector.service', install_dir)
        
        # بناء الحزمة
        subprocess.check_call(['dpkg-deb', '--build', str(deb_dir), 'network-protector_1.0.0_amd64.deb'])
        print("✓ تم إنشاء حزمة DEB بنجاح")
        return True
        
    except Exception as e:
        print(f"✗ فشل في إنشاء حزمة DEB: {e}")
        return False

def create_rpm_package():
    """إنشاء حزمة RPM"""
    try:
        # إنشاء ملف spec
        spec_content = '''Name: network-protector
Version: 1.0.0
Release: 1%{?dist}
Summary: Professional Network Security and Analysis Tool
License: MIT
URL: https://github.com/networksecurity/network-protector
Source0: %{name}-%{version}.tar.gz
BuildArch: x86_64

Requires: python3 >= 3.7
Requires: python3-qt5
Requires: libpcap

%description
Network Protector is a comprehensive network security and analysis tool
that provides real-time network monitoring, threat detection, and router
management capabilities.

%prep
%setup -q

%build
# Nothing to build

%install
rm -rf $RPM_BUILD_ROOT
mkdir -p $RPM_BUILD_ROOT/opt/network-protector
mkdir -p $RPM_BUILD_ROOT/usr/bin
mkdir -p $RPM_BUILD_ROOT/usr/share/applications
mkdir -p $RPM_BUILD_ROOT/etc/systemd/system

cp -r * $RPM_BUILD_ROOT/opt/network-protector/
ln -s /opt/network-protector/network-protector $RPM_BUILD_ROOT/usr/bin/network-protector

if [ -f network-protector.desktop ]; then
    cp network-protector.desktop $RPM_BUILD_ROOT/usr/share/applications/
fi

if [ -f network-protector.service ]; then
    cp network-protector.service $RPM_BUILD_ROOT/etc/systemd/system/
fi

%files
/opt/network-protector/*
/usr/bin/network-protector
/usr/share/applications/network-protector.desktop
/etc/systemd/system/network-protector.service

%post
systemctl daemon-reload
update-desktop-database

%preun
systemctl stop network-protector || true
systemctl disable network-protector || true

%postun
systemctl daemon-reload
update-desktop-database

%changelog
* Wed Jan 01 2025 Network Security Solutions <info@networksecurity.com> - 1.0.0-1
- Initial release
'''
        
        os.makedirs('packaging/rpm', exist_ok=True)
        with open('packaging/rpm/network-protector.spec', 'w') as f:
            f.write(spec_content)
        
        print("✓ تم إنشاء ملف RPM spec")
        return True
        
    except Exception as e:
        print(f"✗ فشل في إنشاء حزمة RPM: {e}")
        return False

def create_appimage():
    """إنشاء AppImage"""
    try:
        appimage_dir = Path('packaging/appimage')
        appimage_dir.mkdir(parents=True, exist_ok=True)
        
        # إنشاء هيكل AppDir
        appdir = appimage_dir / 'NetworkProtector.AppDir'
        appdir.mkdir(exist_ok=True)
        
        # نسخ الملفات
        if os.path.exists('dist/network-protector'):
            shutil.copy2('dist/network-protector', appdir)
        
        # إنشاء ملف AppRun
        apprun_content = '''#!/bin/bash
HERE="$(dirname "$(readlink -f "${0}")")"
export PATH="${HERE}:${PATH}"
exec "${HERE}/network-protector" "$@"
'''
        
        apprun_path = appdir / 'AppRun'
        with open(apprun_path, 'w') as f:
            f.write(apprun_content)
        os.chmod(apprun_path, 0o755)
        
        # نسخ ملف desktop
        if os.path.exists('packaging/linux/network-protector.desktop'):
            shutil.copy2('packaging/linux/network-protector.desktop', appdir)
        
        # إنشاء أيقونة بسيطة
        icon_path = appdir / 'network-protector.png'
        icon_path.touch()  # في التطبيق الحقيقي، ستحتاج أيقونة PNG فعلية
        
        print("✓ تم إنشاء هيكل AppImage")
        print("⚠ لإنهاء بناء AppImage، تحتاج إلى أداة appimagetool")
        return True
        
    except Exception as e:
        print(f"✗ فشل في إنشاء AppImage: {e}")
        return False

def create_install_script():
    """إنشاء سكريپت تثبيت عام"""
    install_script = '''#!/bin/bash

# Network Protector Installation Script
# Supports Ubuntu/Debian, CentOS/RHEL/Fedora

set -e

INSTALL_DIR="/opt/network-protector"
BIN_DIR="/usr/local/bin"
DESKTOP_DIR="/usr/share/applications"
SERVICE_DIR="/etc/systemd/system"

echo "Installing Network Protector..."

# Check for root privileges
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root (use sudo)" 
   exit 1
fi

# Detect distribution
if [ -f /etc/debian_version ]; then
    DISTRO="debian"
    PKG_MANAGER="apt-get"
elif [ -f /etc/redhat-release ]; then
    DISTRO="redhat"
    PKG_MANAGER="yum"
elif [ -f /etc/fedora-release ]; then
    DISTRO="fedora"
    PKG_MANAGER="dnf"
else
    echo "Unsupported distribution"
    exit 1
fi

echo "Detected distribution: $DISTRO"

# Install dependencies
echo "Installing dependencies..."
case $DISTRO in
    "debian")
        $PKG_MANAGER update
        $PKG_MANAGER install -y python3 python3-pyqt5 libpcap0.8 python3-pip
        ;;
    "redhat"|"fedora")
        $PKG_MANAGER install -y python3 python3-qt5 libpcap python3-pip
        ;;
esac

# Install Python packages
pip3 install scapy requests matplotlib pandas psutil

# Create installation directory
mkdir -p "$INSTALL_DIR"

# Copy files
echo "Copying files..."
cp -r dist/network-protector/* "$INSTALL_DIR/" 2>/dev/null || cp dist/network-protector "$INSTALL_DIR/"

# Create symlink
ln -sf "$INSTALL_DIR/network-protector" "$BIN_DIR/network-protector"

# Install desktop file
if [ -f "packaging/linux/network-protector.desktop" ]; then
    cp "packaging/linux/network-protector.desktop" "$DESKTOP_DIR/"
    update-desktop-database 2>/dev/null || true
fi

# Install systemd service
if [ -f "packaging/linux/network-protector.service" ]; then
    cp "packaging/linux/network-protector.service" "$SERVICE_DIR/"
    systemctl daemon-reload
fi

# Set permissions
chmod +x "$INSTALL_DIR/network-protector"
chmod +x "$BIN_DIR/network-protector"

echo ""
echo "Network Protector installed successfully!"
echo ""
echo "Usage:"
echo "  network-protector          # Run GUI application"
echo "  network-protector --help   # Show help"
echo ""
echo "To enable the service:"
echo "  systemctl enable network-protector"
echo "  systemctl start network-protector"
echo ""
'''
    
    with open('install.sh', 'w') as f:
        f.write(install_script)
    os.chmod('install.sh', 0o755)
    
    print("✓ تم إنشاء سكريپت التثبيت العام")

def cleanup_build_files():
    """تنظيف ملفات البناء المؤقتة"""
    dirs_to_remove = ['build', '__pycache__', 'packaging']
    files_to_remove = ['network-protector.spec']
    
    for dir_name in dirs_to_remove:
        if os.path.exists(dir_name):
            shutil.rmtree(dir_name)
            print(f"✓ تم حذف مجلد {dir_name}")
    
    for file_name in files_to_remove:
        if os.path.exists(file_name):
            os.remove(file_name)
            print(f"✓ تم حذف ملف {file_name}")

def main():
    """الدالة الرئيسية للبناء"""
    print("=== Network Protector Linux Build Script ===")
    print()
    
    # التحقق من المتطلبات
    deps = check_dependencies()
    
    if not deps.get('python3', False):
        print("✗ Python 3 مطلوب")
        return False
    
    # تثبيت متطلبات البناء
    if not install_build_dependencies():
        return False
    
    # إنشاء الملفات المطلوبة
    create_desktop_file()
    create_systemd_service()
    
    # بناء الملف التنفيذي
    if not build_pyinstaller_binary():
        return False
    
    # إنشاء الحزم
    success_count = 0
    
    if deps.get('dpkg-deb', False):
        if create_deb_package():
            success_count += 1
    
    if deps.get('rpmbuild', False):
        if create_rpm_package():
            success_count += 1
    
    if create_appimage():
        success_count += 1
    
    # إنشاء سكريپت التثبيت العام
    create_install_script()
    
    print()
    print("=== Build Completed! ===")
    print("الملفات المُنشأة:")
    print("- dist/network-protector (الملف التنفيذي)")
    print("- install.sh (سكريپت التثبيت العام)")
    
    if os.path.exists('network-protector_1.0.0_amd64.deb'):
        print("- network-protector_1.0.0_amd64.deb (حزمة DEB)")
    
    if os.path.exists('packaging/rpm/network-protector.spec'):
        print("- packaging/rpm/network-protector.spec (ملف RPM spec)")
    
    if os.path.exists('packaging/appimage'):
        print("- packaging/appimage/ (هيكل AppImage)")
    
    print()
    print("للتثبيت:")
    print("sudo ./install.sh")
    
    return True

if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1)

