#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Attack Detection Module
وحدة كشف الهجمات والأنشطة المشبوهة
"""

import time
import threading
from collections import defaultdict, deque
from PyQt5.QtCore import QObject, pyqtSignal
import ipaddress

class AttackDetector(QObject):
    """فئة كشف الهجمات والأنشطة المشبوهة"""
    
    # إشارات PyQt
    threat_detected = pyqtSignal(dict)  # إشارة اكتشاف تهديد
    statistics_updated = pyqtSignal(dict)  # إشارة تحديث إحصائيات التهديدات
    
    def __init__(self):
        super().__init__()
        
        # إعدادات الكشف
        self.detection_enabled = {
            'ddos': True,
            'port_scan': True,
            'mitm': True,
            'spoofing': True,
            'suspicious_traffic': True
        }
        
        # حساسية الكشف (low, medium, high)
        self.sensitivity = 'medium'
        
        # عتبات الكشف حسب الحساسية
        self.thresholds = {
            'low': {
                'ddos_packets_per_second': 1000,
                'port_scan_ports_per_minute': 50,
                'connection_attempts_per_minute': 200
            },
            'medium': {
                'ddos_packets_per_second': 500,
                'port_scan_ports_per_minute': 20,
                'connection_attempts_per_minute': 100
            },
            'high': {
                'ddos_packets_per_second': 100,
                'port_scan_ports_per_minute': 10,
                'connection_attempts_per_minute': 50
            }
        }
        
        # بيانات المراقبة
        self.packet_history = deque(maxlen=10000)  # آخر 10000 حزمة
        self.ip_packet_count = defaultdict(lambda: deque(maxlen=1000))  # عدد الحزم لكل IP
        self.port_scan_tracking = defaultdict(set)  # تتبع Port Scanning
        self.connection_attempts = defaultdict(lambda: deque(maxlen=1000))  # محاولات الاتصال
        
        # سجل التهديدات المكتشفة
        self.detected_threats = []
        self.threat_statistics = {
            'ddos_attacks': 0,
            'port_scans': 0,
            'mitm_attempts': 0,
            'spoofing_attempts': 0,
            'suspicious_activities': 0,
            'total_threats': 0
        }
        
        # خيط التحليل
        self.analysis_thread = None
        self.is_analyzing = False
        
        # قائمة الـ IP المحظورة
        self.blocked_ips = set()
        
        # معلومات الشبكة المحلية
        self.local_network = None
        self.gateway_ip = None
        
    def set_sensitivity(self, sensitivity):
        """تعيين حساسية الكشف"""
        if sensitivity in ['low', 'medium', 'high']:
            self.sensitivity = sensitivity
    
    def enable_detection(self, detection_type, enabled=True):
        """تفعيل/إلغاء تفعيل نوع معين من الكشف"""
        if detection_type in self.detection_enabled:
            self.detection_enabled[detection_type] = enabled
    
    def set_local_network_info(self, network_cidr, gateway_ip):
        """تعيين معلومات الشبكة المحلية"""
        try:
            self.local_network = ipaddress.ip_network(network_cidr, strict=False)
            self.gateway_ip = gateway_ip
        except Exception as e:
            print(f"خطأ في تعيين معلومات الشبكة: {e}")
    
    def start_analysis(self):
        """بدء تحليل التهديدات"""
        if self.is_analyzing:
            return
            
        self.is_analyzing = True
        self.analysis_thread = threading.Thread(target=self._analysis_loop)
        self.analysis_thread.daemon = True
        self.analysis_thread.start()
    
    def stop_analysis(self):
        """إيقاف تحليل التهديدات"""
        self.is_analyzing = False
        if self.analysis_thread and self.analysis_thread.is_alive():
            self.analysis_thread.join(timeout=2)
    
    def analyze_packet(self, packet_info):
        """تحليل حزمة واردة للبحث عن تهديدات"""
        current_time = time.time()
        packet_info['analysis_time'] = current_time
        
        # إضافة الحزمة إلى السجل
        self.packet_history.append(packet_info)
        
        # تحليل أنواع التهديدات المختلفة
        threats = []
        
        if self.detection_enabled['ddos']:
            ddos_threat = self._detect_ddos(packet_info, current_time)
            if ddos_threat:
                threats.append(ddos_threat)
        
        if self.detection_enabled['port_scan']:
            port_scan_threat = self._detect_port_scan(packet_info, current_time)
            if port_scan_threat:
                threats.append(port_scan_threat)
        
        if self.detection_enabled['mitm']:
            mitm_threat = self._detect_mitm(packet_info, current_time)
            if mitm_threat:
                threats.append(mitm_threat)
        
        if self.detection_enabled['spoofing']:
            spoofing_threat = self._detect_spoofing(packet_info, current_time)
            if spoofing_threat:
                threats.append(spoofing_threat)
        
        if self.detection_enabled['suspicious_traffic']:
            suspicious_threat = self._detect_suspicious_traffic(packet_info, current_time)
            if suspicious_threat:
                threats.append(suspicious_threat)
        
        # معالجة التهديدات المكتشفة
        for threat in threats:
            self._handle_threat(threat)
    
    def _detect_ddos(self, packet_info, current_time):
        """كشف هجمات DDoS"""
        src_ip = packet_info.get('src_ip', '')
        if not src_ip:
            return None
        
        # تتبع عدد الحزم من كل IP
        self.ip_packet_count[src_ip].append(current_time)
        
        # حساب معدل الحزم في الدقيقة الأخيرة
        recent_packets = [t for t in self.ip_packet_count[src_ip] if current_time - t <= 60]
        packets_per_minute = len(recent_packets)
        packets_per_second = packets_per_minute / 60
        
        threshold = self.thresholds[self.sensitivity]['ddos_packets_per_second']
        
        if packets_per_second > threshold:
            return {
                'type': 'DDoS',
                'severity': 'high',
                'source_ip': src_ip,
                'target_ip': packet_info.get('dst_ip', ''),
                'packets_per_second': packets_per_second,
                'threshold': threshold,
                'timestamp': current_time,
                'description': f'هجوم DDoS محتمل من {src_ip} - {packets_per_second:.1f} حزمة/ثانية'
            }
        
        return None
    
    def _detect_port_scan(self, packet_info, current_time):
        """كشف Port Scanning"""
        src_ip = packet_info.get('src_ip', '')
        dst_port = packet_info.get('dst_port', '')
        protocol = packet_info.get('protocol', '')
        
        if not src_ip or not dst_port or protocol not in ['TCP', 'UDP']:
            return None
        
        # تتبع المنافذ المستهدفة من كل IP
        self.port_scan_tracking[src_ip].add(dst_port)
        
        # حساب عدد المنافذ المختلفة المستهدفة
        unique_ports = len(self.port_scan_tracking[src_ip])
        threshold = self.thresholds[self.sensitivity]['port_scan_ports_per_minute']
        
        if unique_ports > threshold:
            return {
                'type': 'Port Scan',
                'severity': 'medium',
                'source_ip': src_ip,
                'target_ip': packet_info.get('dst_ip', ''),
                'ports_scanned': unique_ports,
                'threshold': threshold,
                'timestamp': current_time,
                'description': f'Port Scanning محتمل من {src_ip} - {unique_ports} منفذ مختلف'
            }
        
        return None
    
    def _detect_mitm(self, packet_info, current_time):
        """كشف هجمات Man-in-the-Middle"""
        # كشف ARP Spoofing (مؤشر على MITM)
        if packet_info.get('protocol') == 'ARP':
            # هنا يمكن إضافة منطق أكثر تعقيداً لكشف ARP Spoofing
            pass
        
        # كشف DNS Spoofing
        if packet_info.get('protocol') == 'DNS':
            # هنا يمكن إضافة منطق كشف DNS Spoofing
            pass
        
        return None
    
    def _detect_spoofing(self, packet_info, current_time):
        """كشف IP/MAC Spoofing"""
        src_ip = packet_info.get('src_ip', '')
        
        if not src_ip:
            return None
        
        # كشف IP Spoofing البسيط
        try:
            src_ip_obj = ipaddress.ip_address(src_ip)
            
            # التحقق من IP addresses غير صالحة أو مشبوهة
            if src_ip_obj.is_private and self.local_network:
                if src_ip_obj not in self.local_network:
                    return {
                        'type': 'IP Spoofing',
                        'severity': 'high',
                        'source_ip': src_ip,
                        'timestamp': current_time,
                        'description': f'IP Spoofing محتمل - IP خارج الشبكة المحلية: {src_ip}'
                    }
        except:
            pass
        
        return None
    
    def _detect_suspicious_traffic(self, packet_info, current_time):
        """كشف الحركة المشبوهة"""
        # كشف الاتصالات على منافذ غير عادية
        dst_port = packet_info.get('dst_port', '')
        protocol = packet_info.get('protocol', '')
        
        if protocol == 'TCP' and dst_port:
            try:
                port_num = int(dst_port)
                # منافذ مشبوهة شائعة
                suspicious_ports = [1234, 4444, 5555, 6666, 7777, 8888, 9999, 31337]
                
                if port_num in suspicious_ports:
                    return {
                        'type': 'Suspicious Traffic',
                        'severity': 'medium',
                        'source_ip': packet_info.get('src_ip', ''),
                        'target_ip': packet_info.get('dst_ip', ''),
                        'port': port_num,
                        'timestamp': current_time,
                        'description': f'حركة مشبوهة على المنفذ {port_num}'
                    }
            except:
                pass
        
        return None
    
    def _handle_threat(self, threat):
        """معالجة التهديد المكتشف"""
        # إضافة التهديد إلى السجل
        self.detected_threats.append(threat)
        
        # تحديث الإحصائيات
        threat_type = threat['type'].lower().replace(' ', '_')
        if threat_type == 'ddos':
            self.threat_statistics['ddos_attacks'] += 1
        elif threat_type == 'port_scan':
            self.threat_statistics['port_scans'] += 1
        elif threat_type == 'mitm' or 'mitm' in threat_type:
            self.threat_statistics['mitm_attempts'] += 1
        elif 'spoofing' in threat_type:
            self.threat_statistics['spoofing_attempts'] += 1
        else:
            self.threat_statistics['suspicious_activities'] += 1
        
        self.threat_statistics['total_threats'] += 1
        
        # إرسال إشارة للواجهة الرسومية
        self.threat_detected.emit(threat)
        
        # اتخاذ إجراء تلقائي إذا كان مفعلاً
        self._take_automatic_action(threat)
    
    def _take_automatic_action(self, threat):
        """اتخاذ إجراء تلقائي ضد التهديد"""
        source_ip = threat.get('source_ip')
        severity = threat.get('severity', 'low')
        
        if source_ip and severity in ['high', 'critical']:
            # حظر IP المصدر
            self.block_ip(source_ip)
    
    def block_ip(self, ip_address):
        """حظر عنوان IP"""
        self.blocked_ips.add(ip_address)
        # هنا يمكن إضافة منطق حظر فعلي (مثل إضافة قاعدة firewall)
    
    def unblock_ip(self, ip_address):
        """إلغاء حظر عنوان IP"""
        self.blocked_ips.discard(ip_address)
        # هنا يمكن إضافة منطق إلغاء الحظر الفعلي
    
    def get_blocked_ips(self):
        """الحصول على قائمة الـ IP المحظورة"""
        return list(self.blocked_ips)
    
    def get_recent_threats(self, count=100):
        """الحصول على آخر التهديدات المكتشفة"""
        return self.detected_threats[-count:] if len(self.detected_threats) > count else self.detected_threats
    
    def get_threat_statistics(self):
        """الحصول على إحصائيات التهديدات"""
        return self.threat_statistics.copy()
    
    def clear_threat_history(self):
        """مسح سجل التهديدات"""
        self.detected_threats.clear()
        self.threat_statistics = {
            'ddos_attacks': 0,
            'port_scans': 0,
            'mitm_attempts': 0,
            'spoofing_attempts': 0,
            'suspicious_activities': 0,
            'total_threats': 0
        }
    
    def _analysis_loop(self):
        """حلقة التحليل المستمر (تعمل في خيط منفصل)"""
        while self.is_analyzing:
            try:
                # تنظيف البيانات القديمة
                self._cleanup_old_data()
                
                # إرسال إحصائيات محدثة
                self.statistics_updated.emit(self.get_threat_statistics())
                
                time.sleep(5)  # تحليل كل 5 ثوان
                
            except Exception as e:
                print(f"خطأ في حلقة التحليل: {e}")
    
    def _cleanup_old_data(self):
        """تنظيف البيانات القديمة"""
        current_time = time.time()
        cleanup_threshold = 300  # 5 دقائق
        
        # تنظيف بيانات تتبع Port Scanning
        for ip in list(self.port_scan_tracking.keys()):
            # إعادة تعيين العداد كل 5 دقائق
            if len(self.port_scan_tracking[ip]) > 0:
                # هنا يمكن إضافة منطق أكثر ذكاءً للتنظيف
                pass
        
        # تنظيف بيانات عدد الحزم القديمة
        for ip in list(self.ip_packet_count.keys()):
            # إزالة الطوابع الزمنية القديمة
            old_timestamps = [t for t in self.ip_packet_count[ip] if current_time - t > cleanup_threshold]
            for timestamp in old_timestamps:
                try:
                    self.ip_packet_count[ip].remove(timestamp)
                except ValueError:
                    pass

