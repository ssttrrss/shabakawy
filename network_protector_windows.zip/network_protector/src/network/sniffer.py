#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Packet Sniffer Module
وحدة التقاط وتحليل حزم الشبكة
"""

import threading
import time
from scapy.all import sniff, get_if_list, get_if_addr
from PyQt5.QtCore import QObject, pyqtSignal
import psutil

class NetworkSniffer(QObject):
    """فئة التقاط حزم الشبكة"""
    
    # إشارات PyQt للتواصل مع الواجهة الرسومية
    packet_captured = pyqtSignal(dict)  # إشارة عند التقاط حزمة
    statistics_updated = pyqtSignal(dict)  # إشارة تحديث الإحصائيات
    error_occurred = pyqtSignal(str)  # إشارة حدوث خطأ
    
    def __init__(self):
        super().__init__()
        self.is_running = False
        self.sniffer_thread = None
        self.interface = None
        self.packet_count = 0
        self.bytes_received = 0
        self.bytes_sent = 0
        self.start_time = None
        
        # إحصائيات الحزم
        self.tcp_packets = 0
        self.udp_packets = 0
        self.icmp_packets = 0
        self.other_packets = 0
        
        # قائمة الحزم المحفوظة (آخر 1000 حزمة)
        self.captured_packets = []
        self.max_packets_to_store = 1000
        
    def get_available_interfaces(self):
        """الحصول على قائمة واجهات الشبكة المتاحة"""
        try:
            interfaces = []
            for iface in get_if_list():
                try:
                    ip = get_if_addr(iface)
                    if ip and ip != "0.0.0.0":
                        interfaces.append({
                            'name': iface,
                            'ip': ip,
                            'description': f"{iface} ({ip})"
                        })
                except:
                    continue
            return interfaces
        except Exception as e:
            self.error_occurred.emit(f"خطأ في الحصول على واجهات الشبكة: {str(e)}")
            return []
    
    def set_interface(self, interface_name):
        """تعيين واجهة الشبكة للمراقبة"""
        self.interface = interface_name
        
    def start_sniffing(self):
        """بدء عملية التقاط الحزم"""
        if self.is_running:
            return False
            
        if not self.interface:
            # اختيار أول واجهة متاحة تلقائياً
            interfaces = self.get_available_interfaces()
            if not interfaces:
                self.error_occurred.emit("لا توجد واجهات شبكة متاحة")
                return False
            self.interface = interfaces[0]['name']
        
        self.is_running = True
        self.start_time = time.time()
        self.reset_statistics()
        
        # بدء خيط منفصل للتقاط الحزم
        self.sniffer_thread = threading.Thread(target=self._sniff_packets)
        self.sniffer_thread.daemon = True
        self.sniffer_thread.start()
        
        return True
    
    def stop_sniffing(self):
        """إيقاف عملية التقاط الحزم"""
        self.is_running = False
        if self.sniffer_thread and self.sniffer_thread.is_alive():
            self.sniffer_thread.join(timeout=2)
    
    def reset_statistics(self):
        """إعادة تعيين الإحصائيات"""
        self.packet_count = 0
        self.bytes_received = 0
        self.bytes_sent = 0
        self.tcp_packets = 0
        self.udp_packets = 0
        self.icmp_packets = 0
        self.other_packets = 0
        self.captured_packets.clear()
    
    def _sniff_packets(self):
        """الدالة الرئيسية لالتقاط الحزم (تعمل في خيط منفصل)"""
        try:
            sniff(
                iface=self.interface,
                prn=self._process_packet,
                stop_filter=lambda x: not self.is_running,
                store=False
            )
        except Exception as e:
            self.error_occurred.emit(f"خطأ في التقاط الحزم: {str(e)}")
    
    def _process_packet(self, packet):
        """معالجة الحزمة الملتقطة"""
        try:
            # تحديث العداد
            self.packet_count += 1
            
            # استخراج معلومات الحزمة
            packet_info = self._extract_packet_info(packet)
            
            # تحديث الإحصائيات
            self._update_statistics(packet_info)
            
            # حفظ الحزمة (آخر 1000 حزمة فقط)
            if len(self.captured_packets) >= self.max_packets_to_store:
                self.captured_packets.pop(0)
            self.captured_packets.append(packet_info)
            
            # إرسال إشارة للواجهة الرسومية
            self.packet_captured.emit(packet_info)
            
            # تحديث الإحصائيات كل 10 حزم
            if self.packet_count % 10 == 0:
                self._emit_statistics()
                
        except Exception as e:
            self.error_occurred.emit(f"خطأ في معالجة الحزمة: {str(e)}")
    
    def _extract_packet_info(self, packet):
        """استخراج معلومات الحزمة"""
        info = {
            'timestamp': time.time(),
            'size': len(packet),
            'protocol': 'Unknown',
            'src_ip': '',
            'dst_ip': '',
            'src_port': '',
            'dst_port': '',
            'summary': packet.summary()
        }
        
        # استخراج معلومات IP
        if packet.haslayer('IP'):
            info['src_ip'] = packet['IP'].src
            info['dst_ip'] = packet['IP'].dst
            
            # تحديد البروتوكول
            if packet.haslayer('TCP'):
                info['protocol'] = 'TCP'
                info['src_port'] = packet['TCP'].sport
                info['dst_port'] = packet['TCP'].dport
                self.tcp_packets += 1
            elif packet.haslayer('UDP'):
                info['protocol'] = 'UDP'
                info['src_port'] = packet['UDP'].sport
                info['dst_port'] = packet['UDP'].dport
                self.udp_packets += 1
            elif packet.haslayer('ICMP'):
                info['protocol'] = 'ICMP'
                self.icmp_packets += 1
            else:
                self.other_packets += 1
        else:
            self.other_packets += 1
        
        return info
    
    def _update_statistics(self, packet_info):
        """تحديث الإحصائيات"""
        self.bytes_received += packet_info['size']
        # هنا يمكن إضافة منطق أكثر تعقيداً لتحديد الاتجاه
    
    def _emit_statistics(self):
        """إرسال إحصائيات محدثة"""
        current_time = time.time()
        duration = current_time - self.start_time if self.start_time else 1
        
        stats = {
            'packet_count': self.packet_count,
            'bytes_received': self.bytes_received,
            'bytes_sent': self.bytes_sent,
            'duration': duration,
            'packets_per_second': self.packet_count / duration,
            'bytes_per_second': self.bytes_received / duration,
            'tcp_packets': self.tcp_packets,
            'udp_packets': self.udp_packets,
            'icmp_packets': self.icmp_packets,
            'other_packets': self.other_packets
        }
        
        self.statistics_updated.emit(stats)
    
    def get_network_interfaces_info(self):
        """الحصول على معلومات مفصلة عن واجهات الشبكة"""
        interfaces_info = []
        
        try:
            # استخدام psutil للحصول على معلومات الشبكة
            net_if_addrs = psutil.net_if_addrs()
            net_if_stats = psutil.net_if_stats()
            
            for interface_name, addresses in net_if_addrs.items():
                interface_info = {
                    'name': interface_name,
                    'addresses': [],
                    'is_up': False,
                    'speed': 0,
                    'mtu': 0
                }
                
                # معلومات العناوين
                for addr in addresses:
                    if addr.family.name == 'AF_INET':  # IPv4
                        interface_info['addresses'].append({
                            'type': 'IPv4',
                            'address': addr.address,
                            'netmask': addr.netmask,
                            'broadcast': addr.broadcast
                        })
                    elif addr.family.name == 'AF_INET6':  # IPv6
                        interface_info['addresses'].append({
                            'type': 'IPv6',
                            'address': addr.address,
                            'netmask': addr.netmask
                        })
                
                # معلومات الحالة
                if interface_name in net_if_stats:
                    stats = net_if_stats[interface_name]
                    interface_info['is_up'] = stats.isup
                    interface_info['speed'] = stats.speed
                    interface_info['mtu'] = stats.mtu
                
                interfaces_info.append(interface_info)
                
        except Exception as e:
            self.error_occurred.emit(f"خطأ في الحصول على معلومات الواجهات: {str(e)}")
        
        return interfaces_info
    
    def get_recent_packets(self, count=100):
        """الحصول على آخر حزم ملتقطة"""
        return self.captured_packets[-count:] if len(self.captured_packets) > count else self.captured_packets
    
    def get_current_statistics(self):
        """الحصول على الإحصائيات الحالية"""
        current_time = time.time()
        duration = current_time - self.start_time if self.start_time else 1
        
        return {
            'packet_count': self.packet_count,
            'bytes_received': self.bytes_received,
            'bytes_sent': self.bytes_sent,
            'duration': duration,
            'packets_per_second': self.packet_count / duration,
            'bytes_per_second': self.bytes_received / duration,
            'tcp_packets': self.tcp_packets,
            'udp_packets': self.udp_packets,
            'icmp_packets': self.icmp_packets,
            'other_packets': self.other_packets,
            'is_running': self.is_running,
            'interface': self.interface
        }

