#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Main Application
التطبيق الرئيسي لحماية الشبكات
"""

import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

# إضافة مسار المشروع إلى sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui.main_window import NetworkProtectorMainWindow

def main():
    """الدالة الرئيسية لتشغيل التطبيق"""
    # إنشاء تطبيق Qt
    app = QApplication(sys.argv)
    
    # تعيين خصائص التطبيق
    app.setApplicationName("Network Protector")
    app.setApplicationVersion("1.0")
    app.setOrganizationName("Network Security Solutions")
    
    # تفعيل High DPI scaling
    app.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    # إنشاء النافذة الرئيسية
    main_window = NetworkProtectorMainWindow()
    main_window.show()
    
    # تشغيل حلقة الأحداث
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()


