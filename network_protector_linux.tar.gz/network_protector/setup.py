#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Setup Script
سكريبت الإعداد والتثبيت
"""

from setuptools import setup, find_packages
import os
import sys

# قراءة ملف README
def read_readme():
    try:
        with open('README.md', 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return "Network Protector - أداة حماية الشبكات"

# قراءة متطلبات التثبيت
def read_requirements():
    try:
        with open('requirements.txt', 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    except:
        return [
            'PyQt5>=5.15.0',
            'scapy>=2.4.0',
            'requests>=2.25.0',
            'matplotlib>=3.3.0',
            'pandas>=1.2.0',
            'psutil>=5.8.0'
        ]

setup(
    name="network-protector",
    version="1.0.0",
    author="Network Security Solutions",
    author_email="info@networksecurity.com",
    description="أداة احترافية لحماية وتحليل الشبكات",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/networksecurity/network-protector",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: System Administrators",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: System :: Networking :: Monitoring",
        "Topic :: Security",
    ],
    python_requires=">=3.7",
    install_requires=read_requirements(),
    extras_require={
        'dev': [
            'pytest>=6.0',
            'pytest-qt>=4.0',
            'black>=21.0',
            'flake8>=3.8',
        ],
    },
    entry_points={
        'console_scripts': [
            'network-protector=main:main',
        ],
        'gui_scripts': [
            'network-protector-gui=main:main',
        ],
    },
    include_package_data=True,
    package_data={
        '': ['*.txt', '*.md', '*.yml', '*.yaml'],
        'assets': ['*'],
    },
    zip_safe=False,
    keywords="network security monitoring protection firewall intrusion detection",
    project_urls={
        "Bug Reports": "https://github.com/networksecurity/network-protector/issues",
        "Source": "https://github.com/networksecurity/network-protector",
        "Documentation": "https://network-protector.readthedocs.io/",
    },
)

