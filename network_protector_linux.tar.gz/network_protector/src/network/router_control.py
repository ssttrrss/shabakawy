#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Router Control Module
وحدة التحكم في الراوتر وإدارة إعدادات الشبكة
"""

import requests
import time
import base64
import hashlib
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse
from PyQt5.QtCore import QObject, pyqtSignal
import re

class RouterController(QObject):
    """فئة التحكم في الراوتر"""
    
    # إشارات PyQt
    connection_status_changed = pyqtSignal(bool, str)  # حالة الاتصال، رسالة
    router_info_updated = pyqtSignal(dict)  # معلومات الراوتر محدثة
    operation_completed = pyqtSignal(str, bool, str)  # العملية، نجحت، رسالة
    device_list_updated = pyqtSignal(list)  # قائمة الأجهزة محدثة
    
    def __init__(self):
        super().__init__()
        
        # معلومات الاتصال
        self.router_ip = None
        self.username = None
        self.password = None
        self.session = requests.Session()
        self.is_connected = False
        
        # معلومات الراوتر
        self.router_info = {
            'model': 'Unknown',
            'firmware': 'Unknown',
            'mac_address': 'Unknown',
            'wan_ip': 'Unknown',
            'lan_ip': 'Unknown',
            'wifi_ssid': 'Unknown',
            'wifi_enabled': False,
            'uptime': 'Unknown'
        }
        
        # قائمة الأجهزة المتصلة
        self.connected_devices = []
        
        # أنواع الراوترات المدعومة
        self.supported_routers = {
            'tp-link': {
                'login_path': '/userRpm/LoginRpm.htm',
                'status_path': '/userRpm/StatusRpm.htm',
                'wireless_path': '/userRpm/WlanNetworkRpm.htm',
                'dhcp_path': '/userRpm/AssignedIpAddrListRpm.htm',
                'reboot_path': '/userRpm/SysRebootRpm.htm'
            },
            'd-link': {
                'login_path': '/login.php',
                'status_path': '/status.php',
                'wireless_path': '/wireless.php',
                'dhcp_path': '/dhcp.php',
                'reboot_path': '/reboot.php'
            },
            'netgear': {
                'login_path': '/base.htm',
                'status_path': '/RST_status.htm',
                'wireless_path': '/WLG_wireless.htm',
                'dhcp_path': '/LAN_lan.htm',
                'reboot_path': '/SYS_reboot.htm'
            },
            'linksys': {
                'login_path': '/login.htm',
                'status_path': '/Status_Router.asp',
                'wireless_path': '/Wireless_Basic.asp',
                'dhcp_path': '/Status_Lan.asp',
                'reboot_path': '/apply.cgi'
            }
        }
        
        # نوع الراوتر المكتشف
        self.router_type = None
        
    def detect_router(self, router_ip):
        """اكتشاف نوع الراوتر"""
        self.router_ip = router_ip
        
        try:
            # محاولة الوصول إلى الصفحة الرئيسية
            response = self.session.get(f"http://{router_ip}", timeout=5)
            
            if response.status_code == 200:
                content = response.text.lower()
                
                # اكتشاف نوع الراوتر من المحتوى
                if 'tp-link' in content or 'tplink' in content:
                    self.router_type = 'tp-link'
                elif 'd-link' in content or 'dlink' in content:
                    self.router_type = 'd-link'
                elif 'netgear' in content:
                    self.router_type = 'netgear'
                elif 'linksys' in content:
                    self.router_type = 'linksys'
                else:
                    # محاولة اكتشاف عام
                    self.router_type = 'generic'
                
                return self.router_type
            
        except Exception as e:
            print(f"خطأ في اكتشاف الراوتر: {e}")
        
        return None
    
    def connect_to_router(self, router_ip, username='admin', password='admin'):
        """الاتصال بالراوتر"""
        self.router_ip = router_ip
        self.username = username
        self.password = password
        
        try:
            # اكتشاف نوع الراوتر أولاً
            if not self.detect_router(router_ip):
                self.connection_status_changed.emit(False, "فشل في اكتشاف نوع الراوتر")
                return False
            
            # محاولة تسجيل الدخول
            if self._login():
                self.is_connected = True
                self.connection_status_changed.emit(True, f"تم الاتصال بالراوتر ({self.router_type})")
                
                # الحصول على معلومات الراوتر
                self._get_router_info()
                return True
            else:
                self.connection_status_changed.emit(False, "فشل في تسجيل الدخول")
                return False
                
        except Exception as e:
            self.connection_status_changed.emit(False, f"خطأ في الاتصال: {str(e)}")
            return False
    
    def _login(self):
        """تسجيل الدخول إلى الراوتر"""
        try:
            if self.router_type == 'tp-link':
                return self._login_tplink()
            elif self.router_type == 'd-link':
                return self._login_dlink()
            elif self.router_type == 'netgear':
                return self._login_netgear()
            elif self.router_type == 'linksys':
                return self._login_linksys()
            else:
                return self._login_generic()
                
        except Exception as e:
            print(f"خطأ في تسجيل الدخول: {e}")
            return False
    
    def _login_tplink(self):
        """تسجيل الدخول إلى راوتر TP-Link"""
        try:
            # TP-Link يستخدم Basic Authentication أو form-based
            auth_string = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
            
            # محاولة Basic Auth أولاً
            headers = {'Authorization': f'Basic {auth_string}'}
            response = self.session.get(f"http://{self.router_ip}/userRpm/StatusRpm.htm", 
                                      headers=headers, timeout=5)
            
            if response.status_code == 200 and 'status' in response.text.lower():
                return True
            
            # محاولة form-based login
            login_data = {
                'username': self.username,
                'password': self.password,
                'login': 'Login'
            }
            
            response = self.session.post(f"http://{self.router_ip}/userRpm/LoginRpm.htm", 
                                       data=login_data, timeout=5)
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"خطأ في تسجيل دخول TP-Link: {e}")
            return False
    
    def _login_dlink(self):
        """تسجيل الدخول إلى راوتر D-Link"""
        try:
            # D-Link غالباً ما يستخدم Basic Auth
            auth_string = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
            headers = {'Authorization': f'Basic {auth_string}'}
            
            response = self.session.get(f"http://{self.router_ip}/status.php", 
                                      headers=headers, timeout=5)
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"خطأ في تسجيل دخول D-Link: {e}")
            return False
    
    def _login_netgear(self):
        """تسجيل الدخول إلى راوتر Netgear"""
        try:
            # Netgear يستخدم Basic Auth
            auth_string = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
            headers = {'Authorization': f'Basic {auth_string}'}
            
            response = self.session.get(f"http://{self.router_ip}/RST_status.htm", 
                                      headers=headers, timeout=5)
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"خطأ في تسجيل دخول Netgear: {e}")
            return False
    
    def _login_linksys(self):
        """تسجيل الدخول إلى راوتر Linksys"""
        try:
            # Linksys يستخدم Basic Auth
            auth_string = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
            headers = {'Authorization': f'Basic {auth_string}'}
            
            response = self.session.get(f"http://{self.router_ip}/Status_Router.asp", 
                                      headers=headers, timeout=5)
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"خطأ في تسجيل دخول Linksys: {e}")
            return False
    
    def _login_generic(self):
        """تسجيل دخول عام للراوترات غير المعروفة"""
        try:
            # محاولة Basic Auth
            auth_string = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
            headers = {'Authorization': f'Basic {auth_string}'}
            
            # محاولة عدة مسارات شائعة
            common_paths = ['/', '/status.html', '/status.htm', '/index.html', '/main.html']
            
            for path in common_paths:
                try:
                    response = self.session.get(f"http://{self.router_ip}{path}", 
                                              headers=headers, timeout=3)
                    if response.status_code == 200:
                        return True
                except:
                    continue
            
            return False
            
        except Exception as e:
            print(f"خطأ في تسجيل الدخول العام: {e}")
            return False
    
    def _get_router_info(self):
        """الحصول على معلومات الراوتر"""
        try:
            if not self.is_connected:
                return
            
            if self.router_type == 'tp-link':
                self._get_tplink_info()
            elif self.router_type == 'd-link':
                self._get_dlink_info()
            elif self.router_type == 'netgear':
                self._get_netgear_info()
            elif self.router_type == 'linksys':
                self._get_linksys_info()
            else:
                self._get_generic_info()
            
            self.router_info_updated.emit(self.router_info)
            
        except Exception as e:
            print(f"خطأ في الحصول على معلومات الراوتر: {e}")
    
    def _get_tplink_info(self):
        """الحصول على معلومات راوتر TP-Link"""
        try:
            response = self.session.get(f"http://{self.router_ip}/userRpm/StatusRpm.htm", timeout=5)
            if response.status_code == 200:
                content = response.text
                
                # استخراج معلومات من HTML
                self.router_info['model'] = self._extract_info(content, r'Model.*?(\w+)', 'TP-Link Router')
                self.router_info['lan_ip'] = self.router_ip
                
        except Exception as e:
            print(f"خطأ في الحصول على معلومات TP-Link: {e}")
    
    def _get_dlink_info(self):
        """الحصول على معلومات راوتر D-Link"""
        try:
            response = self.session.get(f"http://{self.router_ip}/status.php", timeout=5)
            if response.status_code == 200:
                content = response.text
                
                self.router_info['model'] = self._extract_info(content, r'Model.*?(\w+)', 'D-Link Router')
                self.router_info['lan_ip'] = self.router_ip
                
        except Exception as e:
            print(f"خطأ في الحصول على معلومات D-Link: {e}")
    
    def _get_netgear_info(self):
        """الحصول على معلومات راوتر Netgear"""
        try:
            response = self.session.get(f"http://{self.router_ip}/RST_status.htm", timeout=5)
            if response.status_code == 200:
                content = response.text
                
                self.router_info['model'] = self._extract_info(content, r'Model.*?(\w+)', 'Netgear Router')
                self.router_info['lan_ip'] = self.router_ip
                
        except Exception as e:
            print(f"خطأ في الحصول على معلومات Netgear: {e}")
    
    def _get_linksys_info(self):
        """الحصول على معلومات راوتر Linksys"""
        try:
            response = self.session.get(f"http://{self.router_ip}/Status_Router.asp", timeout=5)
            if response.status_code == 200:
                content = response.text
                
                self.router_info['model'] = self._extract_info(content, r'Model.*?(\w+)', 'Linksys Router')
                self.router_info['lan_ip'] = self.router_ip
                
        except Exception as e:
            print(f"خطأ في الحصول على معلومات Linksys: {e}")
    
    def _get_generic_info(self):
        """الحصول على معلومات عامة للراوتر"""
        self.router_info['model'] = 'Generic Router'
        self.router_info['lan_ip'] = self.router_ip
    
    def _extract_info(self, content, pattern, default='Unknown'):
        """استخراج معلومة من محتوى HTML"""
        try:
            match = re.search(pattern, content, re.IGNORECASE)
            return match.group(1) if match else default
        except:
            return default
    
    def change_wifi_password(self, new_password):
        """تغيير كلمة مرور WiFi"""
        try:
            if not self.is_connected:
                self.operation_completed.emit("change_wifi_password", False, "غير متصل بالراوتر")
                return False
            
            success = False
            message = "فشل في تغيير كلمة المرور"
            
            if self.router_type == 'tp-link':
                success, message = self._change_tplink_wifi_password(new_password)
            elif self.router_type == 'd-link':
                success, message = self._change_dlink_wifi_password(new_password)
            elif self.router_type == 'netgear':
                success, message = self._change_netgear_wifi_password(new_password)
            elif self.router_type == 'linksys':
                success, message = self._change_linksys_wifi_password(new_password)
            else:
                message = "نوع الراوتر غير مدعوم لهذه العملية"
            
            self.operation_completed.emit("change_wifi_password", success, message)
            return success
            
        except Exception as e:
            self.operation_completed.emit("change_wifi_password", False, f"خطأ: {str(e)}")
            return False
    
    def _change_tplink_wifi_password(self, new_password):
        """تغيير كلمة مرور WiFi لراوتر TP-Link"""
        try:
            # هذا مثال مبسط - في الواقع يحتاج إلى تحليل أعمق لواجهة الراوتر
            data = {
                'wepType': '1',
                'keytype': '1',
                'key1': new_password,
                'length1': str(len(new_password)),
                'Save': 'Save'
            }
            
            response = self.session.post(f"http://{self.router_ip}/userRpm/WlanNetworkRpm.htm", 
                                       data=data, timeout=10)
            
            if response.status_code == 200:
                return True, "تم تغيير كلمة مرور WiFi بنجاح"
            else:
                return False, "فشل في تغيير كلمة المرور"
                
        except Exception as e:
            return False, f"خطأ في تغيير كلمة مرور TP-Link: {str(e)}"
    
    def _change_dlink_wifi_password(self, new_password):
        """تغيير كلمة مرور WiFi لراوتر D-Link"""
        # تنفيذ مشابه لـ TP-Link مع اختلاف في المعاملات
        return False, "تغيير كلمة مرور D-Link غير مدعوم حالياً"
    
    def _change_netgear_wifi_password(self, new_password):
        """تغيير كلمة مرور WiFi لراوتر Netgear"""
        return False, "تغيير كلمة مرور Netgear غير مدعوم حالياً"
    
    def _change_linksys_wifi_password(self, new_password):
        """تغيير كلمة مرور WiFi لراوتر Linksys"""
        return False, "تغيير كلمة مرور Linksys غير مدعوم حالياً"
    
    def reboot_router(self):
        """إعادة تشغيل الراوتر"""
        try:
            if not self.is_connected:
                self.operation_completed.emit("reboot", False, "غير متصل بالراوتر")
                return False
            
            success = False
            message = "فشل في إعادة تشغيل الراوتر"
            
            if self.router_type == 'tp-link':
                success, message = self._reboot_tplink()
            elif self.router_type == 'd-link':
                success, message = self._reboot_dlink()
            elif self.router_type == 'netgear':
                success, message = self._reboot_netgear()
            elif self.router_type == 'linksys':
                success, message = self._reboot_linksys()
            else:
                message = "نوع الراوتر غير مدعوم لهذه العملية"
            
            self.operation_completed.emit("reboot", success, message)
            
            if success:
                # قطع الاتصال بعد إعادة التشغيل
                self.is_connected = False
                self.connection_status_changed.emit(False, "تم إعادة تشغيل الراوتر")
            
            return success
            
        except Exception as e:
            self.operation_completed.emit("reboot", False, f"خطأ: {str(e)}")
            return False
    
    def _reboot_tplink(self):
        """إعادة تشغيل راوتر TP-Link"""
        try:
            data = {'Reboot': 'Reboot'}
            response = self.session.post(f"http://{self.router_ip}/userRpm/SysRebootRpm.htm", 
                                       data=data, timeout=5)
            
            if response.status_code == 200:
                return True, "تم إرسال أمر إعادة التشغيل"
            else:
                return False, "فشل في إرسال أمر إعادة التشغيل"
                
        except Exception as e:
            return False, f"خطأ في إعادة تشغيل TP-Link: {str(e)}"
    
    def _reboot_dlink(self):
        """إعادة تشغيل راوتر D-Link"""
        return False, "إعادة تشغيل D-Link غير مدعومة حالياً"
    
    def _reboot_netgear(self):
        """إعادة تشغيل راوتر Netgear"""
        return False, "إعادة تشغيل Netgear غير مدعومة حالياً"
    
    def _reboot_linksys(self):
        """إعادة تشغيل راوتر Linksys"""
        return False, "إعادة تشغيل Linksys غير مدعومة حالياً"
    
    def get_connected_devices(self):
        """الحصول على قائمة الأجهزة المتصلة"""
        try:
            if not self.is_connected:
                return []
            
            devices = []
            
            if self.router_type == 'tp-link':
                devices = self._get_tplink_devices()
            elif self.router_type == 'd-link':
                devices = self._get_dlink_devices()
            elif self.router_type == 'netgear':
                devices = self._get_netgear_devices()
            elif self.router_type == 'linksys':
                devices = self._get_linksys_devices()
            
            self.connected_devices = devices
            self.device_list_updated.emit(devices)
            return devices
            
        except Exception as e:
            print(f"خطأ في الحصول على قائمة الأجهزة: {e}")
            return []
    
    def _get_tplink_devices(self):
        """الحصول على قائمة أجهزة TP-Link"""
        try:
            response = self.session.get(f"http://{self.router_ip}/userRpm/AssignedIpAddrListRpm.htm", 
                                      timeout=5)
            if response.status_code == 200:
                # تحليل HTML لاستخراج قائمة الأجهزة
                # هذا مثال مبسط - يحتاج إلى تحليل أعمق للـ HTML الفعلي
                devices = []
                # إضافة منطق تحليل HTML هنا
                return devices
        except Exception as e:
            print(f"خطأ في الحصول على أجهزة TP-Link: {e}")
        
        return []
    
    def _get_dlink_devices(self):
        """الحصول على قائمة أجهزة D-Link"""
        return []
    
    def _get_netgear_devices(self):
        """الحصول على قائمة أجهزة Netgear"""
        return []
    
    def _get_linksys_devices(self):
        """الحصول على قائمة أجهزة Linksys"""
        return []
    
    def block_device(self, mac_address):
        """حظر جهاز بناءً على MAC address"""
        try:
            if not self.is_connected:
                self.operation_completed.emit("block_device", False, "غير متصل بالراوتر")
                return False
            
            # هذه العملية تحتاج إلى تنفيذ مخصص لكل نوع راوتر
            success = False
            message = "حظر الأجهزة غير مدعوم حالياً لهذا النوع من الراوترات"
            
            self.operation_completed.emit("block_device", success, message)
            return success
            
        except Exception as e:
            self.operation_completed.emit("block_device", False, f"خطأ: {str(e)}")
            return False
    
    def set_bandwidth_limit(self, ip_address, download_limit, upload_limit):
        """تحديد حد السرعة لجهاز معين"""
        try:
            if not self.is_connected:
                self.operation_completed.emit("bandwidth_limit", False, "غير متصل بالراوتر")
                return False
            
            # هذه العملية تحتاج إلى تنفيذ مخصص لكل نوع راوتر
            success = False
            message = "تحديد السرعة غير مدعوم حالياً لهذا النوع من الراوترات"
            
            self.operation_completed.emit("bandwidth_limit", success, message)
            return success
            
        except Exception as e:
            self.operation_completed.emit("bandwidth_limit", False, f"خطأ: {str(e)}")
            return False
    
    def disconnect(self):
        """قطع الاتصال مع الراوتر"""
        self.is_connected = False
        self.session.close()
        self.session = requests.Session()
        self.connection_status_changed.emit(False, "تم قطع الاتصال")
    
    def get_router_info(self):
        """الحصول على معلومات الراوتر الحالية"""
        return self.router_info.copy()
    
    def is_router_connected(self):
        """التحقق من حالة الاتصال بالراوتر"""
        return self.is_connected

