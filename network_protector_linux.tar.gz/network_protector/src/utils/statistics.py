#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Protector - Statistics and Reporting Module
وحدة الإحصائيات والتقارير
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QWidget, QVBoxLayout

# تعيين الخط العربي لـ matplotlib
plt.rcParams['font.family'] = ['DejaVu Sans', 'Arial Unicode MS', 'Tahoma']
plt.rcParams['axes.unicode_minus'] = False

class StatisticsGenerator(QObject):
    """مولد الإحصائيات والتقارير"""
    
    # إشارات PyQt
    chart_generated = pyqtSignal(str)  # نوع الرسم البياني المُولد
    report_generated = pyqtSignal(str)  # نوع التقرير المُولد
    
    def __init__(self, database_manager):
        super().__init__()
        self.db = database_manager
        
        # إعدادات الألوان
        self.colors = {
            'primary': '#2196F3',
            'secondary': '#4CAF50',
            'warning': '#FF9800',
            'danger': '#F44336',
            'info': '#00BCD4',
            'success': '#8BC34A',
            'dark': '#424242',
            'light': '#E0E0E0'
        }
        
        # إعدادات الرسوم البيانية
        self.chart_style = 'dark_background'  # أو 'default'
    
    def set_chart_style(self, style='dark_background'):
        """تعيين نمط الرسوم البيانية"""
        self.chart_style = style
        if style == 'dark_background':
            plt.style.use('dark_background')
        else:
            plt.style.use('default')
    
    def generate_network_traffic_chart(self, hours=24, save_path=None):
        """إنشاء رسم بياني لحركة الشبكة"""
        try:
            # الحصول على البيانات
            stats = self.db.get_network_stats(hours=hours)
            if not stats:
                return None
            
            # تحويل البيانات إلى DataFrame
            df = pd.DataFrame(stats)
            df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
            
            # إنشاء الرسم البياني
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
            fig.suptitle(f'حركة الشبكة - آخر {hours} ساعة', fontsize=16, fontweight='bold')
            
            # الرسم الأول: عدد الحزم
            ax1.plot(df['datetime'], df['packets_count'], 
                    color=self.colors['primary'], linewidth=2, label='إجمالي الحزم')
            ax1.plot(df['datetime'], df['tcp_packets'], 
                    color=self.colors['success'], linewidth=1.5, label='حزم TCP')
            ax1.plot(df['datetime'], df['udp_packets'], 
                    color=self.colors['warning'], linewidth=1.5, label='حزم UDP')
            ax1.plot(df['datetime'], df['icmp_packets'], 
                    color=self.colors['info'], linewidth=1.5, label='حزم ICMP')
            
            ax1.set_ylabel('عدد الحزم')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
            
            # الرسم الثاني: البيانات المنقولة
            bytes_mb = df['bytes_received'] / (1024 * 1024)  # تحويل إلى MB
            ax2.fill_between(df['datetime'], bytes_mb, 
                           color=self.colors['secondary'], alpha=0.7, label='البيانات المستلمة (MB)')
            
            ax2.set_ylabel('البيانات (MB)')
            ax2.set_xlabel('الوقت')
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            ax2.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
            self.chart_generated.emit('network_traffic')
            return fig
            
        except Exception as e:
            print(f"خطأ في إنشاء رسم حركة الشبكة: {e}")
            return None
    
    def generate_threat_analysis_chart(self, days=7, save_path=None):
        """إنشاء رسم بياني لتحليل التهديدات"""
        try:
            # الحصول على البيانات
            start_time = time.time() - (days * 24 * 3600)
            threats = self.db.get_threats(start_time=start_time)
            
            if not threats:
                return None
            
            # تحليل البيانات
            df = pd.DataFrame(threats)
            df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
            df['date'] = df['datetime'].dt.date
            
            # إنشاء الرسم البياني
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f'تحليل التهديدات - آخر {days} أيام', fontsize=16, fontweight='bold')
            
            # الرسم الأول: أنواع التهديدات
            threat_counts = df['threat_type'].value_counts()
            colors = [self.colors['danger'], self.colors['warning'], 
                     self.colors['info'], self.colors['secondary']]
            ax1.pie(threat_counts.values, labels=threat_counts.index, autopct='%1.1f%%',
                   colors=colors[:len(threat_counts)])
            ax1.set_title('توزيع أنواع التهديدات')
            
            # الرسم الثاني: التهديدات حسب الشدة
            severity_counts = df['severity'].value_counts()
            severity_colors = {'high': self.colors['danger'], 'medium': self.colors['warning'], 
                             'low': self.colors['info']}
            bars = ax2.bar(severity_counts.index, severity_counts.values,
                          color=[severity_colors.get(x, self.colors['primary']) for x in severity_counts.index])
            ax2.set_title('التهديدات حسب مستوى الشدة')
            ax2.set_ylabel('عدد التهديدات')
            
            # إضافة قيم على الأعمدة
            for bar in bars:
                height = bar.get_height()
                ax2.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}', ha='center', va='bottom')
            
            # الرسم الثالث: التهديدات عبر الزمن
            daily_threats = df.groupby('date').size()
            ax3.plot(daily_threats.index, daily_threats.values, 
                    color=self.colors['danger'], marker='o', linewidth=2)
            ax3.set_title('التهديدات اليومية')
            ax3.set_ylabel('عدد التهديدات')
            ax3.set_xlabel('التاريخ')
            ax3.grid(True, alpha=0.3)
            
            # الرسم الرابع: أهم مصادر التهديدات
            top_sources = df['source_ip'].value_counts().head(10)
            if len(top_sources) > 0:
                ax4.barh(range(len(top_sources)), top_sources.values, 
                        color=self.colors['warning'])
                ax4.set_yticks(range(len(top_sources)))
                ax4.set_yticklabels(top_sources.index)
                ax4.set_title('أهم مصادر التهديدات')
                ax4.set_xlabel('عدد التهديدات')
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
            self.chart_generated.emit('threat_analysis')
            return fig
            
        except Exception as e:
            print(f"خطأ في إنشاء رسم تحليل التهديدات: {e}")
            return None
    
    def generate_device_statistics_chart(self, save_path=None):
        """إنشاء رسم بياني لإحصائيات الأجهزة"""
        try:
            # الحصول على البيانات
            devices = self.db.get_devices()
            if not devices:
                return None
            
            df = pd.DataFrame(devices)
            
            # إنشاء الرسم البياني
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle('إحصائيات الأجهزة المتصلة', fontsize=16, fontweight='bold')
            
            # الرسم الأول: حالة الأجهزة
            online_count = df['is_online'].sum()
            offline_count = len(df) - online_count
            
            ax1.pie([online_count, offline_count], 
                   labels=['متصل', 'غير متصل'], 
                   autopct='%1.1f%%',
                   colors=[self.colors['success'], self.colors['danger']])
            ax1.set_title('حالة الأجهزة')
            
            # الرسم الثاني: أنواع الأجهزة
            device_types = df['device_type'].value_counts()
            if len(device_types) > 0:
                ax2.bar(range(len(device_types)), device_types.values,
                       color=self.colors['primary'])
                ax2.set_xticks(range(len(device_types)))
                ax2.set_xticklabels(device_types.index, rotation=45, ha='right')
                ax2.set_title('أنواع الأجهزة')
                ax2.set_ylabel('عدد الأجهزة')
            
            # الرسم الثالث: الشركات المصنعة
            vendors = df['vendor'].value_counts().head(8)
            if len(vendors) > 0:
                ax3.pie(vendors.values, labels=vendors.index, autopct='%1.1f%%')
                ax3.set_title('الشركات المصنعة')
            
            # الرسم الرابع: المنافذ المفتوحة
            all_ports = []
            for ports_str in df['open_ports'].dropna():
                try:
                    if isinstance(ports_str, str):
                        ports = eval(ports_str)  # تحويل من string إلى list
                        all_ports.extend(ports)
                except:
                    pass
            
            if all_ports:
                port_counts = pd.Series(all_ports).value_counts().head(10)
                ax4.barh(range(len(port_counts)), port_counts.values,
                        color=self.colors['info'])
                ax4.set_yticks(range(len(port_counts)))
                ax4.set_yticklabels([f'Port {p}' for p in port_counts.index])
                ax4.set_title('أكثر المنافذ المفتوحة')
                ax4.set_xlabel('عدد الأجهزة')
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
            self.chart_generated.emit('device_statistics')
            return fig
            
        except Exception as e:
            print(f"خطأ في إنشاء رسم إحصائيات الأجهزة: {e}")
            return None
    
    def generate_protocol_analysis_chart(self, hours=24, save_path=None):
        """إنشاء رسم بياني لتحليل البروتوكولات"""
        try:
            # الحصول على البيانات
            start_time = time.time() - (hours * 3600)
            packets = self.db.get_packets(start_time=start_time, limit=10000)
            
            if not packets:
                return None
            
            df = pd.DataFrame(packets)
            
            # إنشاء الرسم البياني
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f'تحليل البروتوكولات - آخر {hours} ساعة', fontsize=16, fontweight='bold')
            
            # الرسم الأول: توزيع البروتوكولات
            protocol_counts = df['protocol'].value_counts()
            colors = [self.colors['primary'], self.colors['success'], 
                     self.colors['warning'], self.colors['info']]
            ax1.pie(protocol_counts.values, labels=protocol_counts.index, autopct='%1.1f%%',
                   colors=colors[:len(protocol_counts)])
            ax1.set_title('توزيع البروتوكولات')
            
            # الرسم الثاني: أحجام الحزم
            ax2.hist(df['size'], bins=50, color=self.colors['secondary'], alpha=0.7)
            ax2.set_title('توزيع أحجام الحزم')
            ax2.set_xlabel('حجم الحزمة (بايت)')
            ax2.set_ylabel('عدد الحزم')
            ax2.grid(True, alpha=0.3)
            
            # الرسم الثالث: أهم المنافذ المستهدفة
            dst_ports = df['dst_port'].dropna().value_counts().head(10)
            if len(dst_ports) > 0:
                ax3.bar(range(len(dst_ports)), dst_ports.values,
                       color=self.colors['warning'])
                ax3.set_xticks(range(len(dst_ports)))
                ax3.set_xticklabels(dst_ports.index, rotation=45)
                ax3.set_title('أهم المنافذ المستهدفة')
                ax3.set_ylabel('عدد الحزم')
            
            # الرسم الرابع: أهم مصادر الحركة
            src_ips = df['src_ip'].value_counts().head(10)
            if len(src_ips) > 0:
                ax4.barh(range(len(src_ips)), src_ips.values,
                        color=self.colors['info'])
                ax4.set_yticks(range(len(src_ips)))
                ax4.set_yticklabels(src_ips.index)
                ax4.set_title('أهم مصادر الحركة')
                ax4.set_xlabel('عدد الحزم')
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
            
            self.chart_generated.emit('protocol_analysis')
            return fig
            
        except Exception as e:
            print(f"خطأ في إنشاء رسم تحليل البروتوكولات: {e}")
            return None
    
    def generate_summary_report(self, days=7):
        """إنشاء تقرير ملخص"""
        try:
            start_time = time.time() - (days * 24 * 3600)
            
            # الحصول على الإحصائيات
            summary = self.db.get_statistics_summary(hours=days*24)
            
            # إنشاء التقرير
            report = {
                'period': f'آخر {days} أيام',
                'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'network_summary': {
                    'total_packets': summary.get('packet_stats', {}).get('total_packets', 0),
                    'total_bytes': summary.get('packet_stats', {}).get('total_bytes', 0),
                    'unique_sources': summary.get('packet_stats', {}).get('unique_sources', 0),
                    'unique_destinations': summary.get('packet_stats', {}).get('unique_destinations', 0)
                },
                'security_summary': {
                    'total_threats': sum(summary.get('threat_stats', {}).values()),
                    'threat_breakdown': summary.get('threat_stats', {}),
                    'blocked_ips': len(self.db.get_setting('blocked_ips', '').split(',')) if self.db.get_setting('blocked_ips') else 0
                },
                'device_summary': summary.get('device_stats', {}),
                'recommendations': self._generate_recommendations(summary)
            }
            
            self.report_generated.emit('summary')
            return report
            
        except Exception as e:
            print(f"خطأ في إنشاء التقرير الملخص: {e}")
            return {}
    
    def _generate_recommendations(self, summary):
        """إنشاء توصيات بناءً على الإحصائيات"""
        recommendations = []
        
        # توصيات الأمان
        threat_stats = summary.get('threat_stats', {})
        total_threats = sum(threat_stats.values())
        
        if total_threats > 100:
            recommendations.append({
                'type': 'security',
                'priority': 'high',
                'message': f'تم اكتشاف {total_threats} تهديد. يُنصح بمراجعة إعدادات الأمان.'
            })
        
        if 'DDoS' in threat_stats and threat_stats['DDoS'] > 10:
            recommendations.append({
                'type': 'security',
                'priority': 'high',
                'message': 'تم اكتشاف هجمات DDoS متكررة. يُنصح بتفعيل الحماية المتقدمة.'
            })
        
        # توصيات الشبكة
        device_stats = summary.get('device_stats', {})
        total_devices = device_stats.get('total_devices', 0)
        offline_devices = device_stats.get('offline_devices', 0)
        
        if offline_devices > total_devices * 0.3:
            recommendations.append({
                'type': 'network',
                'priority': 'medium',
                'message': f'{offline_devices} جهاز غير متصل. يُنصح بفحص اتصال الشبكة.'
            })
        
        # توصيات الأداء
        packet_stats = summary.get('packet_stats', {})
        total_packets = packet_stats.get('total_packets', 0)
        
        if total_packets > 1000000:  # مليون حزمة
            recommendations.append({
                'type': 'performance',
                'priority': 'medium',
                'message': 'حركة شبكة عالية. يُنصح بمراقبة الأداء وتحسين الإعدادات.'
            })
        
        return recommendations
    
    def export_data_to_csv(self, data_type, file_path, **kwargs):
        """تصدير البيانات إلى ملف CSV"""
        try:
            if data_type == 'packets':
                data = self.db.get_packets(**kwargs)
            elif data_type == 'threats':
                data = self.db.get_threats(**kwargs)
            elif data_type == 'devices':
                data = self.db.get_devices(**kwargs)
            elif data_type == 'network_stats':
                data = self.db.get_network_stats(**kwargs)
            elif data_type == 'event_logs':
                data = self.db.get_event_logs(**kwargs)
            else:
                return False
            
            if data:
                df = pd.DataFrame(data)
                df.to_csv(file_path, index=False, encoding='utf-8-sig')
                return True
            
            return False
            
        except Exception as e:
            print(f"خطأ في تصدير البيانات: {e}")
            return False

class ChartWidget(QWidget):
    """ويدجت لعرض الرسوم البيانية في PyQt"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.figure = Figure(figsize=(10, 6))
        self.canvas = FigureCanvas(self.figure)
        
        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        self.setLayout(layout)
    
    def plot_data(self, x_data, y_data, title="", xlabel="", ylabel="", color='blue'):
        """رسم بيانات بسيطة"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        ax.plot(x_data, y_data, color=color, linewidth=2)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.grid(True, alpha=0.3)
        
        self.canvas.draw()
    
    def plot_bar_chart(self, labels, values, title="", xlabel="", ylabel="", color='blue'):
        """رسم بياني أعمدة"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        ax.bar(labels, values, color=color)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        
        # تدوير التسميات إذا كانت طويلة
        if any(len(str(label)) > 10 for label in labels):
            ax.tick_params(axis='x', rotation=45)
        
        self.canvas.draw()
    
    def plot_pie_chart(self, labels, values, title=""):
        """رسم بياني دائري"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        ax.pie(values, labels=labels, autopct='%1.1f%%')
        ax.set_title(title)
        
        self.canvas.draw()
    
    def clear_plot(self):
        """مسح الرسم البياني"""
        self.figure.clear()
        self.canvas.draw()

