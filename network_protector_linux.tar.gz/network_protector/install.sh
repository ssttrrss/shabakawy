#!/bin/bash

echo "Installing Network Protector..."

# Check for root privileges
if [ "$EUID" -ne 0 ]; then
    echo "This installer requires root privileges. Please run with sudo."
    exit 1
fi

# Installation directory
INSTALL_DIR="/opt/network-protector"
mkdir -p "$INSTALL_DIR"

# Copy files
echo "Copying files..."
cp -r dist/NetworkProtector/* "$INSTALL_DIR/"

# Create symlink for easy execution
ln -sf "$INSTALL_DIR/NetworkProtector" /usr/local/bin/network-protector

# Create .desktop file for application menu
mkdir -p /usr/share/applications/
cp packaging/linux/network-protector.desktop /usr/share/applications/

# Create systemd service (optional, for background monitoring)
mkdir -p /etc/systemd/system/
cp packaging/linux/network-protector.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable network-protector.service

echo "Installation completed successfully!"
echo "You can now run Network Protector from the application menu or by typing 'network-protector' in the terminal."


